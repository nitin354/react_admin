import React, { useState } from "react";

import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { API_URL } from "../Helper";
import axios from "axios";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const redirect = useNavigate();

  function swalalert(type, Message) {
    Swal.fire({
      type: type,
      text: Message,
    });
  }

  async function userregister() {
    let item = { name, email, password };
    const headerreq = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(item),
    };

   
    var parsedata = "";
    axios.post(`${API_URL}users/user`, item).then((res) => {
      parsedata = res.data;

      if (parsedata.status == false) {
        console.log(parsedata.status);
        swalalert("danger", parsedata.message);
      } else {
        console.log("here");
        setName("");
        setEmail("");
        setPassword("");
        localStorage.setItem("user_info", JSON.stringify(parsedata.user_info));
        swalalert("success", parsedata.message);

        redirect("/Login");
      }

    });
  }

  return (
    <div>
      <div className="container">
        <div className="row ">
          <div className="col-md-4 "></div>
          <div className="col-md-4 my-5">
            <h1>Register</h1>
            <div className=" form-floating mb-3">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="form-control"
                id="floatingname"
                placeholder="Enter Name"
              />
              <label htmlFor="floatingname">Name</label>
            </div>
            <div className=" form-floating mb-3">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="form-control"
                id="floatingInput"
                placeholder="name@example.com"
              />
              <label htmlFor="floatingInput">Email address</label>
            </div>
            <div className="form-floating">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="form-control"
                id="floatingPassword"
                placeholder="Password"
              />
              <label htmlFor="floatingPassword">Password</label>
            </div>
            <Link to="/Login">Login</Link>
            <button
              className="btn btn-primary btn-md my-3"
              onClick={userregister}
            >
              Register
            </button>
          </div>
          <div className="col-md-4 "></div>
        </div>
      </div>
    </div>
  );
}
