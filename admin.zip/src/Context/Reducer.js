import { API_URL } from "../Helper";
import { useEffect } from "react";

export const cartreducer = (state, action) => {
  const { cart, qty } = state;
  let product;
  let index;
  let updatedQty;

  switch (action.type) {
    case "ADD_TO_CART":
      let cartdta = { cart: [...cart, { ...action.payload, qty: 1 }] };
      var cartdata = [...cart];

      if (!cartdata.includes(action.payload)) {
        cartdata.push({ ...action.payload, qty: 1 });
        localStorage.setItem("cart", JSON.stringify(cartdata));
        //setCartItems(array);
      }
      return cartdta;

    case "REMOVE_FROM_CART":
      var cartr = state.cart.filter((c) =>
        c.product_id
          ? c.product_id !== action.payload.product_id
          : c.stock_no !== action.payload.stock_no
      );
      localStorage.setItem("cart", JSON.stringify(cartr));
      return {
        cart: state.cart.filter((c) =>
          c.product_id
            ? c.product_id !== action.payload.product_id
            : c.stock_no !== action.payload.stock_no
        ),
        qty: 0,
      };

    case "INC":
      product = cart.find((c) => c.product_id === action.payload.product_id);
      index = cart.findIndex((c) => c.product_id === action.payload.product_id);
      product.qty = product.qty + 1;
      cart[index] = product;
      return { cart: [...cart], qty: updatedQty };

    case "DES":
      product = cart.find((c) => c.product_id === action.payload.product_id);
      index = cart.findIndex((c) => c.product_id === action.payload.product_id);
      if (product.qty > 1) {
        product.qty = product.qty - 1;
        cart[index] = product;
        return { cart: [...cart], qty: updatedQty };
      }

    default:
      return state;
  }
};
