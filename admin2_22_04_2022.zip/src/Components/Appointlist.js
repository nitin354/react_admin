import { React, useEffect,useState } from 'react';
import { Button,Modal } from "react-bootstrap";
import { API_URL, swalalert } from "../Helper";
import axios from "axios";
import { useNavigate,useParams,Link } from "react-router-dom";
import Sidebar from './Sidebar'

import $ from 'jquery';

function Appointlist(props) {

  const [show, setShow] = useState(false);
const handleClose = () => setShow(false);
const handleShow = () => setShow(true);
const [modalData, setModalData] = useState(null);
  const redirect = useNavigate();
  useEffect(() => {
    $(document).ready(function () {
      setTimeout(function () {
        $('#example').DataTable();
      }, 1000);
    });
  }, [props])


  async function update_status(app_id, status) {
    let item = { appointment_id: app_id, status: status };
    $(`#${app_id}`).hide();

    axios.post(`${API_URL}admin/appointment_change_status`, item).then((res) => {
      var parsedata = res.data;
      if (parsedata.status === 1) {
        redirect("/appointments");
      }
    });

  }

  return (
    <div className="container my-5">
      <table id="example" className="table table-hover table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {props.data && props.data.map((result, index) => {

            if (props.type === "new") {
              var btn = <><Button variant="primary" className='mx-2 whit_co' onClick={() => update_status(result.appointment_id, 3)} > Cancel </Button><Button className='mx-2 whit_co btn-primary'  onClick={() => update_status(result.appointment_id, 2)} > Close </Button></>;
            } else if (props.type === "closed") {
              btn = <><Button variant="primary" className='mx-2 whit_co' onClick={() => update_status(result.appointment_id, 3)} > Cancel </Button><Button className='mx-2 whit_co btn-primary'  onClick={() => update_status(result.appointment_id, 1)} > New </Button></>
            } else {
              btn = <><Button variant="primary" className='mx-2 whit_co' onClick={() => update_status(result.appointment_id, 2)}> Close </Button><Button className='mx-2 whit_co btn-primary'  onClick={() => update_status(result.appointment_id, 1)} > New </Button></>
            }

            return (
              <tr id={result.appointment_id} key={result.appointment_id}>
                <td>{index + 1}</td>
                <td>{result.first_name + " " + result.last_name}</td>
                <td>{result.phone}</td>
                <td>{result.email}</td>
                <td>{btn}<Button className='btn-danger mx-2'  ><Link className='whit_co' to={`/appointments/detail/${result.appointment_id}`}>View</Link></Button></td>
              </tr>
            )
          })}
            

        </tbody>
      </table>

    </div>

  )
}


function Appointdetail() {

  let {app_id} = useParams()
  const redirect = useNavigate();
  const [data, setData] = useState("")
  useEffect(() => {

    let item = { appointment_id:app_id }
    var parsedata = "";
    axios.post(`${API_URL}admin/appointment_details`, item).then((res) => {
      parsedata = res.data;

      setData(parsedata.data);
      // if (parsedata.status == 1) {
      //   setData(parsedata.data);
      // } else {
      //   swalalert("danger", parsedata.message);
      // }

    });



    $(document).ready(function () {
      setTimeout(function () {
        $('#example').DataTable();
      }, 1000);
    });
  }, [])


  async function update_status(app_id, status) {
    let item = { appointment_id: app_id, status: status };
    $(`#${app_id}`).hide();

    axios.post(`${API_URL}admin/appointment_change_status`, item).then((res) => {
      var parsedata = res.data;
      if (parsedata.status === 1) {
        redirect("/appointments");
      }
    });

  }


  return (
    <>
        <Sidebar/>
          <div className="container my-5">
<div>
  <div className="content-wrapper my-5" id="AppointmentDetail">
    <div className="row">
      <div className="col-md-12">
        <h1 className="card-title">Appointment Details</h1>
      </div>
      <div className="col-md-3 mb-3">
        <div className="card">
          <div className="card-body">
            <h1 className="card-title">{data.first_name + " " + data.last_name}</h1>
            <br />
            <div className="icon-bock">
              <div className="icon d-inline-block me-2">
                <svg width={19} height={14} viewBox="0 0 19 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M1 3.18182V2.5C1 1.67157 1.67157 1 2.5 1H16.5C17.3284 1 18 1.67157 18 2.5V3.18182M1 3.18182L8.05729 7.25769M1 3.18182V11.3636M18 3.18182L10.9427 7.25769M18 3.18182V11.3636M10.9427 7.25769L9.5 8.09091L8.05729 7.25769M10.9427 7.25769L18 11.3636M18 11.3636V11.5C18 12.3284 17.3284 13 16.5 13H2.5C1.67157 13 1 12.3284 1 11.5V11.3636M8.05729 7.25769L1 11.3636" stroke="#3059b3" />
                </svg>
              </div>
              <span className="icon-text">Email: </span>
              <p className="icon-heading">{data.email }</p>
            </div>
            <hr />
            <div className="icon-bock">
              <div className="icon d-inline-block me-2">
                <svg width={16} height={16} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" clipRule="evenodd" d="M3.65387 1.32849C3.40343 1.00649 2.92745 0.976861 2.639 1.26531L1.60508 2.29923C1.1216 2.78271 0.94387 3.46766 1.1551 4.06847C2.00338 6.48124 3.39215 8.74671 5.32272 10.6773C7.25329 12.6078 9.51876 13.9966 11.9315 14.8449C12.5323 15.0561 13.2173 14.8784 13.7008 14.3949L14.7347 13.361C15.0231 13.0726 14.9935 12.5966 14.6715 12.3461L12.3653 10.5524C12.2008 10.4245 11.9866 10.3793 11.7845 10.4298L9.59541 10.9771C9.00082 11.1257 8.37183 10.9515 7.93845 10.5181L5.48187 8.06155C5.04849 7.62817 4.87427 6.99919 5.02292 6.40459L5.57019 4.21553C5.62073 4.01336 5.57552 3.79918 5.44758 3.63468L3.65387 1.32849ZM1.88477 0.511076C2.62689 -0.231039 3.85149 -0.154797 4.49583 0.673634L6.28954 2.97983C6.6187 3.40304 6.73502 3.95409 6.60498 4.47423L6.05772 6.66329C5.99994 6.8944 6.06766 7.13888 6.2361 7.30732L8.69268 9.7639C8.86113 9.93235 9.1056 10.0001 9.33671 9.94229L11.5258 9.39502C12.0459 9.26499 12.597 9.3813 13.0202 9.71047L15.3264 11.5042C16.1548 12.1485 16.231 13.3731 15.4889 14.1152L14.455 15.1492C13.7153 15.8889 12.6089 16.2137 11.5778 15.8512C9.01754 14.9511 6.61438 13.4774 4.56849 11.4315C2.5226 9.38562 1.04895 6.98246 0.148838 4.42225C-0.213682 3.39112 0.11113 2.28472 0.85085 1.545L1.88477 0.511076Z" fill="#3059b3" />
                </svg>
              </div>
              <span className="icon-text">Telephone: </span>
              <p className="icon-heading">{data.phone }</p>
            </div>
          </div>
        </div>
      </div>
      <div className="col-md-6">
        <div className="card">
          <div className="card-body">
            <div className="row text-center" style={{borderBottom: '1px solid #ebebeb'}}>
              <div className="col-md-4 border-right">
                <div className="icon-bock">
                  <div className="icon d-inline-block me-2">
                    <svg width={16} height={16} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" clipRule="evenodd" d="M3.5 0C3.77614 0 4 0.223858 4 0.5V1H12V0.5C12 0.223858 12.2239 0 12.5 0C12.7761 0 13 0.223858 13 0.5V1H14C15.1046 1 16 1.89543 16 3V14C16 15.1046 15.1046 16 14 16H2C0.895431 16 0 15.1046 0 14V3C0 1.89543 0.895431 1 2 1H3V0.5C3 0.223858 3.22386 0 3.5 0ZM1 4V14C1 14.5523 1.44772 15 2 15H14C14.5523 15 15 14.5523 15 14V4H1Z" fill="#2A54B2" />
                      <path d="M11 6.5C11 6.22386 11.2239 6 11.5 6H12.5C12.7761 6 13 6.22386 13 6.5V7.5C13 7.77614 12.7761 8 12.5 8H11.5C11.2239 8 11 7.77614 11 7.5V6.5Z" fill="#2A54B2" />
                    </svg>
                  </div>
                  <span className="icon-text">Date: </span>
                </div>
                <p className="icon-heading">{data.date }</p>
              </div>
              <div className="col-md-4 border-right">
                <div className="icon-bock">
                  <div className="icon d-inline-block me-2">
                    <svg width={16} height={16} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path fillRule="evenodd" clipRule="evenodd" d="M8 15C11.866 15 15 11.866 15 8C15 4.13401 11.866 1 8 1C4.13401 1 1 4.13401 1 8C1 11.866 4.13401 15 8 15ZM16 8C16 12.4183 12.4183 16 8 16C3.58172 16 0 12.4183 0 8C0 3.58172 3.58172 0 8 0C12.4183 0 16 3.58172 16 8Z" fill="#2A54B2" />
                      <path fillRule="evenodd" clipRule="evenodd" d="M7.94954 3.29492C8.18056 3.29492 8.36784 3.50561 8.36784 3.76551V8.66883L11.0851 10.4157C11.2857 10.5446 11.3554 10.8321 11.2408 11.0577C11.1262 11.2834 10.8706 11.3618 10.6701 11.2328L7.74201 9.3505C7.61168 9.26672 7.53125 9.1108 7.53125 8.94192V3.76551C7.53125 3.50561 7.71853 3.29492 7.94954 3.29492Z" fill="#2A54B2" />
                    </svg>
                  </div>
                  <span className="icon-text">Time: </span>
                </div>
                <p className="icon-heading">{data.time }</p>
              </div>
              <div className="col-md-4">
                <div className="icon-bock">
                  <div className="icon d-inline-block me-2">
                    <svg width={18} height={16} viewBox="0 0 18 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <mask id="path-1-inside-1_232_1915" fill="white">
                        <rect width={18} height="10.8" rx={1} />
                      </mask>
                      <rect width={18} height="10.8" rx={1} stroke="#2A54B2" strokeWidth="2.2" mask="url(#path-1-inside-1_232_1915)" />
                      <path d="M9.38971 8.0748L11.5548 11.8248C11.728 12.1248 11.5115 12.4998 11.1651 12.4998H6.83493C6.48853 12.4998 6.27202 12.1248 6.44523 11.8248L8.61029 8.0748C8.78349 7.7748 9.21651 7.7748 9.38971 8.0748Z" fill="#EBEBEB" stroke="#2A54B2" strokeWidth="1.1" />
                    </svg>
                  </div>
                  <span className="icon-text">Type: </span>
                </div>
                <p className="icon-heading">{data.meeting_type}</p>
              </div>
            </div>
            <div className="simple-box pt-3">
              <p><b>Comment:</b></p>
              <p className="comment-block">{data.comment}</p>
            </div>
            <div className="simple-box pt-1 d-inline-block">
              <p className="me-5"><b>Product:</b> <span /></p>
            </div>
            
            

            
            <p className="card-text mr-2">Status: <span className="badge badge-warning">{data.status == 1? "pending":"close" }</span></p>
            {/* <button onclick="changeStatusAppointment(2,9)" className="submit-btn  btn btn-sm btn-success"> <i className="loader29 mdi mdi-spin hide mdi-loading me-2" /> Close</button>
            <button onclick="changeStatusAppointment(3,9)" className="submit-btn  btn btn-sm btn-danger"> <i className="loader39 mdi mdi-spin hide mdi-loading me-2" />Cancel</button> */}
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

</>)
}


export {Appointlist,Appointdetail} 