import { React, useEffect, useState } from "react";
import { API_URL, swalalert } from "../Helper";
import axios from "axios";
import { Button } from 'react-bootstrap';
import { useNavigate,useParams } from "react-router-dom";
import Sidebar from './Sidebar';
import Select from "react-select";


function Addcoupon() {
  const [data, setData] = useState([])
  const [catdata, setCatdata] = useState([])
  const [cust, setCust] = useState(false)
  const [apply, setApply] = useState(false)
  const [minper, setMinper] = useState(false)

  let navigate = useNavigate();

  const [couponcode, setCouponcode] = useState("");
  const [discounttype, setDicounttype] = useState(1);
  const [entireorder, setEntireorder] = useState("");
  const [discountvalue, setDiscountvalue] = useState("");
  const [minpurchaseamount, setMinpurchaseamount] = useState("");
  const [customerId, setCustomerId] = useState();
  const [limitonepercustomer, setLimitonepercustomer] = useState("");
  const [usagelimits, setUsagelimits] = useState("");
  const [categoryids, setCategoryids] = useState();
  const [startdatetime, setStartdatetime] = useState("");
  const [enddatetime, setEnddatetime] = useState("");

  async function savecoupon() {


    let coupondata = {
      coupon_code: couponcode,
      discount_type: discounttype,
      entire_order: entireorder,
      discount_value: discountvalue,
      min_purchase_amount: minpurchaseamount,
      customerId: customerId,
      limit_one_per_customer: limitonepercustomer,
      usage_limits: usagelimits,
      category_ids: categoryids,
      start_datetime: startdatetime,
      end_datetime: enddatetime
    };

    console.log(coupondata);
    var parsedata = "";
    axios.post(`${API_URL}admin/add_coupon`, coupondata).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        swalalert("success", "Coupon Added Successfully");
        navigate("/coupon");
      } else {
        swalalert("error", parsedata.message);
      }

    });
  }

  function getOptions() {
    let url = `${API_URL}admin/User_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });
  }


  function getCateg() {
    let url_cat = `${API_URL}admin/Category_list`;
    axios.get(url_cat).then((res) => {
      const parsedata1 = res.data;
      setCatdata(parsedata1.data)
    });

  }

  function handleChange(e) {
    setCustomerId(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
  }

  function catChange(e) {
    setCategoryids(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
  }

var catoptions = [];
var useroptions = [];


  useEffect(() => {
    getOptions()
    getCateg()
  }, [])

  
  return (
    <>
      <Sidebar />
      <div className='container my-5'><div className=" text-center my-5">
        <h3>Add Banner</h3>
      </div>
    <div><div className="page-content page-content-left">
      <div className="row">
        <div className="col-md-12">
          <div className="card">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code</label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" value={couponcode}
                        onChange={(e) => setCouponcode(e.target.value)} className="form-control" required="required" placeholder="EG:SUMMERSALE"  style={{ textTransform: 'uppercase' }} />
                    </div>

                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{ color: 'red' }} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" required="required" name="discount_type" value={1}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" defaultChecked="checked" />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" required="required" name="discount_type" value={0}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{ color: 'red' }} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" defaultChecked className="form-check-input entire_order" value={1}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(false)} name="entire_order" id="optionsRadios" />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" value={0}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(true)} />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {apply ? <div id="customer_div" style={{}} data-select2-id="customer_div">
                        { catdata.map((element) => {
                          if(element.name != null  ){
                             catoptions.push( {value: element.category_id ,label : element.name } );
                          }
                    })   
                    }

                    <Select  isMulti  options={catoptions}   onChange={catChange}  />
                      </div> : ""}
                  </div>
        
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" name="discount_value" value={discountvalue}
                    onChange={(e) => setDiscountvalue(e.target.value)} required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none" defaultChecked="checked" value={0}
                        onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" id="optionsRadios" onClick={() => setMinper(false)}   />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" onClick={() => setMinper(true)} />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  {minper?<input type="number" className="form-control min_purchase_amt" value={minpurchaseamount}
                    onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" placeholder="$ 0.00" min={0} />:""

                  }
                  
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={() => setCust(false)} defaultChecked="checked" />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>


                  <div className="form-check" >
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={() => setCust(true)} />
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">
                        {
                          data.map((element) => {
                          if(element.first_name != null  ){
                            useroptions.push( {value: element.user_id ,label : element.first_name } );
                          }
                         })   
                        }
                        <Select isMulti options={useroptions} value={data.filter(obj => categoryids.includes(obj.value))} onChange={handleChange}/>
                      </div> : ""
                    }
                  </div>

                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" value={1}
                        onChange={(e) => setLimitonepercustomer(e.target.value)} name="limit_one_per_customer" id="optionsRadios" />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" value={2}
                         name="usage_limits" />
                      Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                { minper?<><div className="form-group col-md-6"><label>&nbsp;</label><input type="number" onChange={(e) => setUsagelimits(e.target.value)} className="form-control number_of_times" name="usage_limits" placeholder={1} min={0} /></div></>:""}
                
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input  type="date" id="start_date" value={startdatetime}
                      onChange={(e) => setStartdatetime(e.target.value)} required="required" className="form-control" name="start_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input  type="date" id="end_date" className="form-control" value={enddatetime}
                      onChange={(e) => setEnddatetime(e.target.value)} required="required" name="end_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <Button className="btn btn-primary" onClick={savecoupon}>
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    </div>
    </div>
    </>
  )
}


 function Editcoupon() {
  const [data, setData] = useState([])
  const [catdata, setCatdata] = useState([])
  const [cust, setCust] = useState()
  const [apply, setApply] = useState()
  const [minper, setMinper] = useState()
  const [catapply, setCatapply] = useState()
  const [limit, setLimit] = useState()
  const [usage, setUsage] = useState()

  let navigate = useNavigate();

  const [ecouponcode, setCouponcode] = useState("");
  const [ediscounttype, setDicounttype] = useState("");
  const [entireorder, setEntireorder] = useState("");
  const [discountvalue, setDiscountvalue] = useState("");
  const [minpurchaseamount, setMinpurchaseamount] = useState("");
  const [customerId, setCustomerId] = useState("");
  const [limitonepercustomer, setLimitonepercustomer] = useState("");
  const [usagelimits, setUsagelimits] = useState("");
  const [categoryids, setCategoryids] = useState("");
  const [startdatetime, setStartdatetime] = useState("");
  const [enddatetime, setEnddatetime] = useState("");
  
const {coupon_id} = useParams()
  async function updatecoupon() {
    let coupondata = {
      id: coupon_id,
      coupon_code: ecouponcode,
      discount_type: ediscounttype,
      entire_order: entireorder,
      discount_value: discountvalue,
      min_purchase_amount: minpurchaseamount,
      customerId: customerId,
      limit_one_per_customer: limitonepercustomer,
      usage_limits: usagelimits,
      category_ids: categoryids,
      start_datetime: startdatetime,
      end_datetime: enddatetime
    };

    var parsedata = "";
    axios.post(`${API_URL}admin/add_coupon`, coupondata).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        swalalert("success", "Coupon Updated Successfully");
        navigate("/coupon");
      } else {
        swalalert("error", parsedata.message);
      }

    });
  }

  function getOptions() {
    let url = `${API_URL}admin/User_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });

  }


  function getCateg() {
    let url_cat = `${API_URL}admin/Category_list`;
    axios.get(url_cat).then((res) => {
      const parsedata1 = res.data;
      setCatdata(parsedata1.data)
    });
  }

  function handleChange(e) {
    setCustomerId(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
  }

  function catChange(e) {
    setCategoryids(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
  }


 function usagehandlechange(e) {
    const { checked } = e.target
    setUsage(checked?true:false)
  }

var catoptions = [];
var useroptions = [];

  useEffect(() => {
    let item = {id:coupon_id}
    var parsedata = "";
    axios.post(`${API_URL}admin/coupon_detail`, item).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        setCouponcode(parsedata.data.coupon_code);
        setDicounttype(parsedata.data.discount_type);
        setEntireorder(parsedata.data.entire_order);
        setDiscountvalue(parsedata.data.discount_value);
        setMinpurchaseamount(parsedata.data.min_purchase_amount);
        setCustomerId(parsedata.data.customerId);
        setLimitonepercustomer(parsedata.data.limit_one_per_customer);
        setUsagelimits(parsedata.data.usage_limits);
        setCategoryids(parsedata.data.category_ids);
        setStartdatetime(parsedata.data.start_datetime);
        setEnddatetime(parsedata.data.end_datetime);
         setCust(parsedata.data.customerId.length > 0 ? true:false)
         setApply(parsedata.data.category_ids.length > 0 ?true:false)
         setMinper(parsedata.data.min_purchase_amount > 0 ?true:false)
         setLimit(parsedata.data.limit_one_per_customer > 0 ?true:false)
         setUsage(parsedata.data.usage_limits > 0 ?true:false)
      } else {
        swalalert("danger", parsedata.message);
      }

    });

    getOptions()
    getCateg()

  }, [])




 
  return (
    <>
      <Sidebar />
      <div className='container my-5'><div className=" text-center my-5">
        <h3>Add Banner</h3>
      </div>
    <div><div className="page-content page-content-left">
      <div className="row">
        <div className="col-md-12">
          <div className="">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code </label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" value={ecouponcode}
                        onChange={(e) => setCouponcode(e.target.value)} className="form-control" required="required" placeholder="EG:SUMMERSALE"  style={{ textTransform: 'uppercase' }} />
                    </div>
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{ color: 'red' }} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={1}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" checked={ ediscounttype == 1 ? "checked":"" } />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={0}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" checked={ ediscounttype == 0 ? "checked":"" } />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{ color: 'red' }} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio"  className="form-check-input entire_order" value={1}
                        onChange={(e) => setEntireorder(e.target.value)} defaultChecked={apply} onClick={() => setApply(false)} name="entire_order" id="optionsRadios" />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" value={2}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(true)}  defaultChecked={apply} />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {apply ? <div id="customer_div" style={{}} data-select2-id="customer_div">
                         { catdata.map((element) => {
                            catoptions.push( {value: element.category_id ,label : element.name } );
                          })   
                        }
                          <Select isMulti options={catoptions}  value={catoptions.filter(cat => categoryids.includes(cat.value))} onChange={catChange}/>
                      </div> : ""}

                  </div>
               
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" name="discount_value" value={discountvalue}
                    onChange={(e) => setDiscountvalue(e.target.value)} required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none"  value={0}
                        onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" id="optionsRadios" onClick={() => setMinper(false)} defaultChecked />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" onClick={() => setMinper(true)}   checked={minper} />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  {minper?<input type="number" className="form-control min_purchase_amt" value={minpurchaseamount}
                    onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" placeholder="$ 0.00" min={0} />:""
                  }
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={() => setCust(false)} defaultChecked={cust} />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check" >
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={() => setCust(true)} defaultChecked={cust}/>
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">

                              {
                              data.map((element) => {
                              if(element.first_name != null  ){
                                useroptions.push( {value: element.user_id ,label : element.first_name } );
                              }
                              })   
                              }
                              <Select isMulti options={useroptions} value={useroptions.filter(cat => customerId.includes(cat.value))} onChange={handleChange}/>
                      </div> : ""
                    }
                  </div>

                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" value={1}
                        onChange={(e) => setLimitonepercustomer(e.target.value)} name="limit_one_per_customer" id="optionsRadios" checked={limit} />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" onChange={usagehandlechange} checked={usage}
                         name="usage_limits" />
                         Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                {usage?<div className="form-group col-md-6">
                  <label>&nbsp;</label>
                  <input type="number" className="form-control number_of_times" value={usagelimits} onChange={(e) => setUsagelimits(e.target.value)} name="usage_limits" placeholder={1} min={0}  />
                </div>:""
                }
                
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input  type="date" id="start_date" value={startdatetime}
                      onChange={(e) => setStartdatetime(e.target.value)} required="required" className="form-control" name="start_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input  type="date" id="end_date" className="form-control" value={enddatetime}
                      onChange={(e) => setEnddatetime(e.target.value)} required="required" name="end_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
              </div>


              <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <Button className="btn btn-primary" onClick={updatecoupon}>
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    </div>
    </div>
    </>
  )
}

export {Addcoupon,Editcoupon} 