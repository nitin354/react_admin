import React,{useEffect} from "react";

import { Link, useNavigate } from "react-router-dom";

function Sidebar() {

    let user_info = localStorage.getItem("user_info")
    ? JSON.parse(localStorage.getItem("user_info"))
    : "";
  const redirect = useNavigate();

 
  function logout() {
    localStorage.setItem("user_info", "");
    //IsLogin()
      //window.location.href = "/"
    //  redirect("/");
  }
  function IsLogin(){
    if(user_info){
      if(user_info.length <= 0){
        redirect("/");
      }
      // else{
      //   redirect("/dashboard");
      // }
    }else{
      redirect("/");
    }
      
    } 

useEffect(() => {
  IsLogin()
  
}, [user_info])



  return (
    <div className=''>            
    <nav id="sidebar">
       <div>
  <div className="sidebar_blog_1">
    <div className="sidebar-header">
      <div className="logo_section">
        <Link to="/dashboard"></Link>
      </div>
    </div>
    <div className="sidebar_user_info">
      <div className="icon_setting" />
      <div className="user_profle_side">
        <div className="user_img"><img className="img-responsive" src="https://showcase.belgiumwebnet.com/webapi/assets/admin/images/bw.png" alt="#" /></div>
        <div className="user_info">
          <h6>{user_info.name}</h6>
          <p><span className="online_animation" /> Online</p>
        </div>
      </div>
    </div>
  </div>
  <div className="sidebar_blog_2">
    <h4>General</h4>
    <ul className="list-unstyled components">
      <li className="active">
        <Link to="/dashboard" ><i className="fa fa-dashboard yellow_color" /> <span>Dashboard</span></Link>
        {/* <ul className="collapse list-unstyled" id="dashboard">
          <li>
            <a href="dashboard.html">&gt; <span>Default Dashboard</span></a>
          </li>
          <li>
            <a href="dashboard_2.html">&gt; <span>Dashboard style 2</span></a>
          </li>
        </ul> */}
      </li>
      <li><Link to="/customers"><i className="fa fa-clock-o orange_color" /> <span>Customer</span></Link></li>
      <li>
        <Link to="/appointments" ><i className="fa fa-diamond purple_color" /> <span>Appoinments</span></Link>
       
      </li>
      <li><Link to="/category"><i className="fa fa-table purple_color2" /> <span>Category</span></Link></li>
      <li>
        <Link to="/coupon" ><i className="fa fa-object-group blue2_color" /> <span>Coupon</span></Link>
        
      </li>
      <li><Link to="/banner"><i className="fa fa-briefcase blue1_color" /> <span>Banner</span></Link></li>
      {/* <li>
        <a href="contact.html">
          <i className="fa fa-paper-plane red_color" /> <span>Contact</span></a>
      </li> */}
      {/* <li className="active">
        <a href="#additional_page" data-toggle="collapse" aria-expanded="false" className="dropdown-toggle"><i className="fa fa-clone yellow_color" /> <span>Additional Pages</span></a>
        <ul className="collapse list-unstyled" id="additional_page">
          <li>
            <a href="profile.html">&gt; <span>Profile</span></a>
          </li>
          <li>
            <a href="project.html">&gt; <span>Projects</span></a>
          </li>
          <li>
            <a href="login.html">&gt; <span>Login</span></a>
          </li>
          <li>
            <a href="404_error.html">&gt; <span>404 Error</span></a>
          </li>
        </ul>
      </li> */}
      {/* <li><a href="map.html"><i className="fa fa-map purple_color2" /> <span>Map</span></a></li>
      <li><a href="charts.html"><i className="fa fa-bar-chart-o green_color" /> <span>Charts</span></a></li>
      <li><a href="settings.html"><i className="fa fa-cog yellow_color" /> <span>Settings</span></a></li> */}
    </ul>
  </div>
</div>

    </nav> <div id="content">
  <div className="topbar">
    <nav className="navbar navbar-expand-lg navbar-light">
      <div className="full">
        
        
        <div className="right_topbar">
          <div className="icon_info">
            {/* <ul>
              <li><a href="#"><i className="fa fa-bell-o" /><span className="badge">2</span></a></li>
              <li><a href="#"><i className="fa fa-question-circle" /></a></li>
              <li><a href="#"><i className="fa fa-envelope-o" /><span className="badge">3</span></a></li>
            </ul> */}
            <ul className="user_profile_dd">
              <li>
                <a className="dropdown-toggle" data-toggle="dropdown"><img className="img-responsive rounded-circle" src="https://showcase.belgiumwebnet.com/webapi/assets/admin/images/bw.png" alt="#" /><span className="name_user">{user_info && user_info.name}</span></a>
                <div className="dropdown-menu">
                  <Link className="dropdown-item" to="#" onClick={logout}><span>Log Out</span> <i className="fa fa-sign-out" /></Link>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  </div>
</div>
</div>
  )
}

export default Sidebar