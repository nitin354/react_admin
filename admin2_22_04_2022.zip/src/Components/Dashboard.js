import { React, useEffect, useState } from 'react';
import { Button, Modal } from "react-bootstrap";
import { API_URL,IsLogin } from "../Helper";
import axios from "axios";
import Cardcount from './Cardcount';
import Sidebar from './Sidebar'
import { Link,useNavigate } from 'react-router-dom';

function Dashboard() {

  const [customers, setCustomers] = useState(0)
  const [orders, setOrders] = useState(0)
  const [jewelry, setJewelry] = useState(0)
  const [appointments, setAppointments] = useState(0)
  const [naturaldiamonds, setNaturaldiamonds] = useState(0)
  const [labdiamonds, setLabdiamonds] = useState(0)
  const [fancydiamonds, setFancydiamonds] = useState(0)
  const [gemstones, setGemstones] = useState(0)
  const [reviews, setReviews] = useState(0)
  const [blogs, setBlogs] = useState(0)
  const [apppointment, setAppointment] = useState([])
  const [order, setOrder] = useState([])
 
 
  function get_dashboard() {

    let url = `${API_URL}admin/dashboard`;

    axios.get(url).then((res) => {
      const parsedata = res.data;
      if (parsedata.status === 1) {
        setAppointment(parsedata.data.appointmentsList);
        setOrder(parsedata.data.ordersList)
        setCustomers(parsedata.data.customers)
        setOrders(parsedata.data.orders)
        setJewelry(parsedata.data.jewelry)
        setAppointments(parsedata.data.appointments)
        setNaturaldiamonds(parsedata.data.naturaldiamonds)
        setLabdiamonds(parsedata.data.labdiamonds)
        setFancydiamonds(parsedata.data.fancydiamonds)
        setGemstones(parsedata.data.gemstones)
        setReviews(parsedata.data.reviews)
        setBlogs(parsedata.data.blogs)
      }
    });
  }

  
  useEffect(() => {
        
  get_dashboard()

  }, [])


  return (
    <>
      <Sidebar />
      <div className="midde_cont">
        <div className="container-fluid">
          <div className="row column_title">
            <div className="col-md-12">
              <div className="page_title">
                <h2>Dashboard</h2>
              </div>
            </div>
          </div>
          <div className="row column1">
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 yellow_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-user " />
                  </div>
                </div>
                <Cardcount name={"Customers"} count={customers} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 blue1_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-shopping-cart " />
                  </div>
                </div>
                <Cardcount name={"orders"} count={orders} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 green_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-cloud-download " />
                  </div>
                </div>
                <Cardcount name={"jewelry"} count={jewelry} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 red_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-handshake-o " />
                  </div>
                </div>
                <Cardcount name={"appointments"} count={appointments} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 red_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-diamond " />
                  </div>
                </div>
                <Cardcount name={"natural diamonds"} count={naturaldiamonds} />
              </div>
            </div>

            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 yellow_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-diamond " />
                  </div>
                </div>
                <Cardcount name={"lab diamonds"} count={labdiamonds} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 red_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-diamond " />
                  </div>
                </div>
                <Cardcount name={"fancy diamonds"} count={fancydiamonds} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 yellow_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-diamond " />
                  </div>
                </div>
                <Cardcount name={"gemstones"} count={gemstones} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 blue1_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-comments-o " />
                  </div>
                </div>
                <Cardcount name={"reviews"} count={reviews} />
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="full counter_section margin_bottom_30 green_bg">
                <div className="couter_icon">
                  <div>
                    <i className="fa fa-comments-o " />
                  </div>
                </div>
                <Cardcount name={"blogs"} count={blogs} />
              </div>
            </div>

          </div>



          <div className='row my-5'>
            <div className='col-md-6'>
              <h3 className="text-center" >Appointments</h3>
              <table id="example23" className="table table-hover table-bordered">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Comment</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {apppointment && apppointment.map((result, index) => {
                    return (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{result.first_name + " " + result.last_name}</td>
                        <td>{result.comment}</td>
                        <td><Button variant="primary" ><Link className='whit_co' to={`/appointments/detail/${result.appointment_id}`}> View </Link> </Button></td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>

            <div className='col-md-6'>
              <h3 className="text-center" >Orders</h3>
              <table id="example16" className="table table-hover table-bordered">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>status</th>
                    <th>Date</th>
                    <th>price</th>
                  </tr>
                </thead>
                <tbody>
                  {order && order.map((result1, ind) => {
                    if (result1.order_status == 0) {
                      var status = "pending";
                    } else if (result1.order_status == 1) {
                      var status = "Completed";
                    }
                    return (
                      <tr key={ind}>
                        <td>{ind + 1}</td>
                        <td>{result1.first_name + " " + result1.last_name}</td>
                        <td> {status} </td>
                        <td>{result1.created_at}</td>
                        <td> {result1.order_total} </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

      </div></>)
}

export default Dashboard