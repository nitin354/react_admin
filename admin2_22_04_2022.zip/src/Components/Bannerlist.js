import  {React,useEffect,useState} from 'react';
import { API_URL, BANNER_URL,swalalert } from "../Helper";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import $ from 'jquery';
import { Image,Button } from 'react-bootstrap';
import Sidebar from './Sidebar';

function Bannerlist() {

    const [data, setData] = useState([])
    let navigate = useNavigate();

    function getdata(){
      let url = `${API_URL}admin/banner_list`;
      axios.get(url).then((res) => {
        const parsedata = res.data;
        setData(parsedata.data)
     
      });
    }
  

    useEffect(() => {
      getdata()

        $(document).ready(function () {
            setTimeout(function(){
                $('#coupon').DataTable();
                 } ,1000);
            
          });
    }, [])

    async function update_status(app_id, status) {
        let item = { id: app_id, status: status };
        $(`#${app_id}`).hide();
    
        axios.post(`${API_URL}admin/status_banner`, item).then((res) => {
          var parsedata = res.data;
       
          if (parsedata.status === 1) {
            swalalert("success", parsedata.message);
            getdata()
            navigate("/banner");
          }else{
            swalalert("error", parsedata.message);
          }
    
        });
    
      }
    



  return (
    <>
    <Sidebar />
    <div className="container my-5">
    <div className=" text-center my-5">
        <h3>Banner List</h3>
      </div>
      <div className="text-center my-5">
          <Button variant="primary" className='text-center' onClick={()=> navigate("/addbanner")}>
            Add Banner
          </Button>
        </div>
     <div className="container my-5">


<table id="coupon" className="table table-hover table-bordered">
<thead>
<tr>
  <th>ID</th>
  <th>Title</th>
  <th>Image</th>
  <th>Mobile Image</th>
  <th>Link</th>
  <th>Status</th>
  <th>Action</th>
</tr>
</thead>
<tbody>
{data && data.map((result, index) => {

  if (result.status === 1) {
    var btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.slider_id, 0)} > Cancel </Button></>;
  } else if (result.status === 0) {
    btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.slider_id, 1)} > Cancel </Button></>
  }

  return (
    <tr key={result.slider_id}>
      <td>{index + 1}</td>
      <td>{result.title}</td>
      <td className=''><Image src={BANNER_URL+result.image} height={50} width={50} className="img-responsive"   ></Image></td>
      <td className=''><Image src={BANNER_URL+result.mobile_image} height={50} width={50}  className="img-responsive"  ></Image></td>
      <td>{result.btn_link}</td>
      <td>{result.status}</td>
      <td>{result.status == 1 ? <><Button className='btn-danger mx-2' onClick={() => update_status(result.slider_id, 0)} > Deactivate </Button> </> : <><Button className='btn-success mx-2' onClick={() => update_status(result.slider_id, 1)} > Activate </Button></> 
                    }<Button className='btn-danger mx-2' ><Link className='whit_co' to={`/banner/edit/${result.slider_id}`}>Edit</Link></Button></td>



    </tr>
  )
})}


</tbody>
</table>

</div>
</div>
</>
  )
}

export default Bannerlist