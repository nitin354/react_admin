
import Swal from "sweetalert2";
import { useNavigate } from "react-router-dom";



 export const API_URL = "https://showcase.belgiumwebnet.com/webapi/api/";
 export const BANNER_URL = "https://showcase.belgiumwebnet.com/webapi/assets/images/home/frontslider/";
 export function swalalert(type, Message) {

    Swal.fire({
      icon: type,
      title: '',
      text: Message,
      footer: ''
    })
  }




