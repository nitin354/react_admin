import React, { useState, useEffect } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { API_URL } from "../Helper";
import axios from "axios";
import Swal from "sweetalert2";
import App from "../App";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(localStorage.getItem("user_info") ? localStorage.getItem("user_info") : []);
  let navigate = useNavigate();

  function swalalert(type, Message) {
    Swal.fire({
      type: type,
      text: Message,
    });
  }

  async function loginuser() {
    let item = { email, password };
    var parsedata = "";
    axios.post(`${API_URL}admin/login`, item).then((res) => {
      parsedata = res.data;
      //console.log(parsedata);
      if (parsedata.status == false) {
        swalalert("danger", parsedata.message);
      } else {
        localStorage.setItem("user_info", JSON.stringify(parsedata.data));
        setUser(localStorage.getItem("user_info"))
        setEmail("");
        setPassword("");
        navigate("/dashboard");

      }

    });
  }


  return (
    < >
      <div className="container ">
        <div className="center verticle_center full_height">
          <div className="login_section">
            <div className="logo_login">
              <div className="center">
                <img width={210} src="images/logo/logo.png" alt="#" />
              </div>
            </div>
            <div className="login_form">
             
                <fieldset>
                  <div className="field">
                    <label className="label_field">Email Address</label>
                    <input type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)} name="email" placeholder="E-mail" />
                  </div>
                  <div className="field">
                    <label className="label_field">Password</label>
                    <input type="password" value={password}
                      onChange={(e) => setPassword(e.target.value)} name="password" placeholder="Password" />
                  </div>

                  <div className="field margin_0">
                    <label className="label_field hidden">hidden label</label>
                    <button className="main_bt" onClick={loginuser}>Sing In</button>
                  </div>
                </fieldset>
             
            </div>
          </div>
        </div>

      </div>
    </>
  );
}
