import { React, useEffect } from 'react';

import { Button } from "react-bootstrap";
import { API_URL } from "../Helper";
import axios from "axios";

import { useNavigate, Redirect } from "react-router-dom";

import $ from 'jquery';

function Appointlist(props) {

  const redirect = useNavigate();

  useEffect(() => {
    $(document).ready(function () {
      setTimeout(function () {
        $('#example').DataTable();
      }, 1000);
    });
  }, [])


  async function update_status(app_id, status) {
    let item = { appointment_id: app_id, status: status };
    $(`#${app_id}`).hide();

    axios.post(`${API_URL}admin/appointment_change_status`, item).then((res) => {
      var parsedata = res.data;
      console.log(parsedata.status);
      if (parsedata.status === 1) {
        redirect("/appointments");
      }

    });

  }





  return (


    <div className="container my-5">

      <table id="example" className="table table-hover table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {props.data && props.data.map((result, index) => {

            if (props.type === "new") {
              var btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.appointment_id, 3)} > Cancel </Button><Button className='mx-2' variant="info" onClick={() => update_status(result.appointment_id, 2)} > Close </Button></>;
            } else if (props.type === "closed") {
              btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.appointment_id, 3)} > Cancel </Button><Button className='mx-2' variant="info" onClick={() => update_status(result.appointment_id, 1)} > New </Button></>
            } else {

              btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.appointment_id, 2)}> Close </Button><Button className='mx-2' variant="info" onClick={() => update_status(result.appointment_id, 1)} > New </Button></>

            }

            return (
              <tr id={result.appointment_id} key={result.appointment_id}>
                <td>{index + 1}</td>
                <td>{result.first_name + " " + result.last_name}</td>
                <td>{result.phone}</td>
                <td>{result.email}</td>
                <td>{btn}</td>



              </tr>
            )
          })}


        </tbody>
      </table>

    </div>

  )
}

export default Appointlist