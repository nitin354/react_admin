import  {React,useEffect,useState} from 'react';
import { API_URL, BANNER_URL } from "../Helper";
import axios from "axios";

import $ from 'jquery';
import { Image,Button } from 'react-bootstrap';
import Sidebar from './Sidebar';

function Bannerlist() {

    const [data, setData] = useState([])
  

    useEffect(() => {
        let url = `${API_URL}admin/banner_list`;
        axios.get(url).then((res) => {
          const parsedata = res.data;
          setData(parsedata.data)
       
        });

        $(document).ready(function () {
            setTimeout(function(){
                $('#coupon').DataTable();
                 } ,1000);
            
          });
    }, [])

    async function update_status(app_id, status) {
        let item = { id: app_id, status: status };
        $(`#${app_id}`).hide();
    
        axios.post(`${API_URL}admin/status_banner`, item).then((res) => {
          var parsedata = res.data;
          console.log(parsedata.status);
          if (parsedata.status === 1) {
            // redirect("/appointments");
          }
    
        });
    
      }
    



  return (
    <>
    <Sidebar />
    <div className="container my-5">
    <div className=" text-center my-5">
        <h3>BannerList</h3>
      </div>
     <div className="container my-5">


<table id="coupon" className="table table-hover table-bordered">
<thead>
<tr>
  <th>ID</th>
  <th>Title</th>
  <th>Image</th>
  <th>Mobile Image</th>
  <th>Link</th>
  <th>Status</th>
  <th>Action</th>
</tr>
</thead>
<tbody>
{data && data.map((result, index) => {

  if (data.status === 1) {
    var btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.slider_id, 0)} > Cancel </Button></>;
  } else if (data.status === 0) {
    btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.slider_id, 1)} > Cancel </Button></>
  }

  return (
    <tr key={result.slider_id}>
      <td>{index + 1}</td>
      <td>{result.title}</td>
      <td className='banner_img'><Image src={BANNER_URL+result.image} className="img-responsive"   ></Image></td>
      <td className='banner_img'><Image src={BANNER_URL+result.mobile_image} className="img-responsive"  ></Image></td>
      <td>{result.btn_link}</td>
      <td>{result.status}</td>
      <td>{btn}</td>



    </tr>
  )
})}


</tbody>
</table>

</div>
</div>
</>
  )
}

export default Bannerlist