import {React,useState,useEffect} from 'react';
import { API_URL } from "../Helper";
import axios from "axios";
import { Modal,Button } from "react-bootstrap";


import $ from 'jquery'; 
import Sidebar from './Sidebar';

function Category() {
    const [data, setData] = useState([])
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    useEffect(() => {
        let url = `${API_URL}admin/Category_list`;
      

        axios.get(url).then((res) => {
          const parsedata = res.data;
         
          setData(parsedata.data)
        });

        $(document).ready(function () {
            setTimeout(function(){
            $('#example').DataTable();
             } ,1000);
        });
    }, [])
    
  return (
    
    <>
      <Sidebar />
      <div className="container my-5">
    <div className=" text-center my-5">
        <h3>Coustomerlist</h3>
    </div>
     
    <div className="container">
         
        <table id="example" className="table table-hover table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            {/* <th>Company</th>
            <th>Action</th> */}
          </tr>
        </thead>
        <tbody>
        {data && data.map((result,index) => {
          return (
               <tr key={index}>
                <td>{index+1}</td>
                <td>{result.name}</td>
              </tr>
          )
        })}
          
           
        </tbody>
      </table>
         
      </div>
    </div>
    </>
  )
}

export default Category