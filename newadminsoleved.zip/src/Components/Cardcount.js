import React from 'react'
import { Card, Button } from "react-bootstrap";
function Cardcount(props) {

  return (<><div className="counter_no">
  <div>
    <p className="total_no">{props.count}</p>
    <p className="head_couter">{props.name.toUpperCase()}</p>
  </div>
</div></>)
}

export default Cardcount