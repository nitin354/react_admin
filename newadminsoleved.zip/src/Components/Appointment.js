import {React,useEffect,useState} from 'react'
import Appointlist from './Appointlist';
import { API_URL } from "../Helper";
import axios from "axios";
import {  Tab,Tabs } from "react-bootstrap";

import Sidebar from './Sidebar';

function Appointment() {
    const [data, setData] = useState([])
    const [closedata, setClosedata] = useState([])
    const [canceldata, setCanceldata] = useState([])
    const [key, setKey] = useState('home');

    useEffect(() => {
        let url = `${API_URL}/admin/appointment_list`;
        axios.get(url).then((res) => {
          const parsedata = res.data;
          setData(parsedata.data.new_list)
          setClosedata(parsedata.data.closed_list)
          setCanceldata(parsedata.data.cancelled_list)

        });

    }, [key])
    

        return (
          <>
          <Sidebar />
          <div className="container my-5">
          
          <div className=" text-center my-5">
        <h3>Appointments</h3>
      </div>
            <div className='container my5'>
                
          <Tabs
            id="controlled-tab-example"
            activeKey={key}
            onSelect={(k) => setKey(k)}
            className="mb-3 my-5"
          >
            <Tab eventKey="home" title="New Appointment">
              <Appointlist  type="new"  data={data}/>
            </Tab>
            <Tab eventKey="profile" title="Close Appointment">
            <Appointlist type="closed" data={closedata} />
            </Tab>
            <Tab eventKey="contact"  title="Cancel Appintment" >
            <Appointlist  type="cancel"  data={canceldata} />
            </Tab>
          </Tabs>
          </div>
          </div>
          </>
        );
      
 
}

export default Appointment