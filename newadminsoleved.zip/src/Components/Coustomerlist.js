import { React, useState, useEffect } from 'react';
import { API_URL } from "../Helper";
import axios from "axios";
import { Button, Modal } from "react-bootstrap";

import "bootstrap/dist/css/bootstrap.min.css";

import $ from 'jquery';
import Sidebar from './Sidebar';

function Coustomerlist() {
  const [data, setData] = useState([])
  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [modalData, setModalData] = useState(null);

  useEffect(() => {
    let url = `${API_URL}/admin/customer_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      //console.log(parsedata.data)
      setData(parsedata.data)
    });

    $(document).ready(function () {
      setTimeout(function () {
        $('#examplecust').DataTable();
      }, 1000);
    });
  }, [])
  // console.log(modalData)
  return (
    <>
      <Sidebar />
      <div className="container my-5">

        <div className=" text-center my-5">
          <h3>Coustomer List</h3>
        </div>

        <div className="container my-5">
          <table id="examplecust" className="table table-hover table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Company</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {data && data.map((result, index) => {
                return (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>{result.first_name + " " + result.last_name}</td>
                    <td>{result.company}</td>
                    <td><Button variant="primary" onClick={() => {
                      setModalData(result);
                      handleShow();
                    }}  > View </Button></td>

                  </tr>
                )
              })}
            </tbody>
          </table>


          <Modal show={show} onHide={handleClose} size="lg">
            <Modal.Header closeButton>
              <Modal.Title>Customer Detail</Modal.Title>
            </Modal.Header>
            <Modal.Body className='text-center'>
              {modalData ? <div><p><label>Name : </label> {modalData.first_name + " " + modalData.last_name}</p>
                <p><label>Company : </label> {modalData.company}</p>
                <p><label>Email : </label> {modalData.email}</p>
                <p><label>Phone : </label> {modalData.phone}</p></div> : ""
              }
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>

            </Modal.Footer>
          </Modal>

        </div>
      </div>
    </>
  )
}



export default Coustomerlist