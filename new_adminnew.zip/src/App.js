import './App.css';
import Dashboard from './Components/Dashboard';
import "bootstrap/dist/css/bootstrap.min.css";

import Login from './Components/Login';

import { BrowserRouter, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Coustomerlist from "./Components/Coustomerlist";
import 'jquery/dist/jquery.min.js';

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import Appointment from "./Components/Appointment";
import Category from "./Components/Category";
import Couponlist from "./Components/Couponlist";
import Bannerlist from "./Components/Bannerlist";
import Addbaner from './Components/Addbaner';
function App() {

  let user_info = localStorage.getItem("user_info")
  ? true
  : false;
  return (
    <div className="App dashboard dashboard_1">
    <div className='full_container'>
    <div className='inner_container'>
    
  
    <BrowserRouter>
          <Routes>
            <Route exact path="/" element={<Login />} />
            <Route exact path="/dashboard" element={<Dashboard />} />
            <Route exact path="/customers" element={<Coustomerlist />}/>
            <Route exact path="/appointments" element={<Appointment />}/>
            <Route exact path="/category" element={<Category />}/>
            <Route exact path="/coupon" element={<Couponlist />}/>
            <Route exact path="/banner" element={<Bannerlist />}/>
            <Route exact path="/addbanner" element={<Addbaner />}/>

          </Routes>
    </BrowserRouter>
    </div>
    </div>
    </div>
  );
}

export default App;
