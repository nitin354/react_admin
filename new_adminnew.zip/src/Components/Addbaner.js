
import Sidebar from './Sidebar'
import { useState } from 'react'
import { API_URL, swalalert } from "../Helper";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Addbaner() {

  const [title, setTitle] = useState("");
  const [short_text, setShort_text] = useState("");
  const [btn_text, setBtn_text] = useState("");
  const [btn_link, setBtn_link] = useState("");
  const [display_order, setDisplay_order] = useState("");
  const [text_direction_class, setText_direction_class] = useState("");
  const [extra_class, setExtra_class] = useState("");
  const [image, setImage] = useState("");
  const [mob_image, setMob_image] = useState("");
  const [alt_text, setAlt_text] = useState("");
  let navigate = useNavigate();

  console.log(mob_image);

  async function savebanner() {


    let coupondata = {

      title:title,
short_text:short_text,
btn_tex:btn_text,
image:image,
mob_image:mob_image,
btn_link:btn_link,
alt_tag:alt_text,
display_order:display_order,
text_direction_class:text_direction_class,
extra_class:extra_class

  
    };


    var parsedata = "";
    const config = {
        headers: {
          'content-type': 'multipart/form-data',
        },
      };
    axios.post(`${API_URL}admin/add_banner`, coupondata,config).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        navigate("/banner");
      } else {
        swalalert("danger", parsedata.message);
      }

    });
  }
  
  return (
      <>
    <Sidebar />
<div className='container my-5'><div className=" text-center my-5">
        <h3>Add Banner</h3>
      </div><div className="content-wrapper auth">
    <div className="row flex-grow">
      <div className="col-md-12">
        {/* <h1 className="card-title">Add Banner</h1> */}
      </div>
      <div className="col-md-8 grid-margin stretch-card">
        <div className="card">
          <div className="card-body">
            <div id="res-msg" />
            
              <div className="row">
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Title<span style={{color: 'red'}}>*</span></label>
                  <input type="text" required name="title" className="form-control" value={title}
                        onChange={(e) => setTitle(e.target.value)} id="banner-name" placeholder="Name" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Short Text<span style={{color: 'red'}}>*</span></label>
                  <input type="text" required name="short_text" value={short_text}
                        onChange={(e) => setShort_text(e.target.value)} className="form-control" id="short-name" placeholder="Short Text" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Button Text<span style={{color: 'red'}}>*</span></label>
                  <input type="text" required name="btn_text" value={btn_text}
                        onChange={(e) => setBtn_text(e.target.value)} className="form-control" id="button-text" placeholder="Button Text" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Button Link<span style={{color: 'red'}}>*</span></label>
                  <div className="input-group">
                    <div className="input-group-prepend">
                      <span className="input-group-text">https://showcase.belgiumwebnet.com/webapi/</span>
                    </div>
                    <input type="text" required name="btn_link" value={btn_link}
                        onChange={(e) => setBtn_link(e.target.value)} className="form-control" id="btn-name" placeholder="Button Link" />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Display Order <span style={{color: 'red'}}>*</span></label>
                  <input type="number" required name="display_order" value={display_order}
                        onChange={(e) => setDisplay_order(e.target.value)} className="form-control" min={1} id="btn-name" defaultValue={1} placeholder="Display Order Of Banners" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Text Direction Class <span style={{color: 'red'}}>*</span></label>
                  <select required className="form-control form-control-sm" data-width="100%" value={text_direction_class}
                        onChange={(e) => setText_direction_class(e.target.value)} name="text_direction_class" data-select2-id={1} tabIndex={-1} aria-hidden="true">
                    <option value data-select2-id={3}>Select Class</option>
                    <option value="text-left">Text Left</option>
                    <option value="text-center">Text Center</option>
                    <option value="text-right">Text Right</option>
                  </select>
                </div>
                <div className="form-group col-md-6 hide">
                  <label htmlFor="brand-name">Extra Class<span style={{color: 'red'}}>*</span></label>
                  <input type="text" name="extra_class" value={extra_class}
                        onChange={(e) => setExtra_class(e.target.value)} className="form-control" id="btn-name" placeholder="Extra Class" />
                </div>
                <div className="form-group col-md-6">
                  <label>Desktop Image<span style={{color: 'red'}}>*</span></label>
                  <input type="file" 
                        onChange={(e) => setImage(e.target.files)} required name="image" className="form-control" />
                </div>
                <div className="form-group col-md-6">
                  <label>Mobile Image<span style={{color: 'red'}}>*</span></label>
                  <input type="file" 
                        onChange={(e) => setMob_image(e.target.files)} required name="mob_image" className="form-control" />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="brand-name">Alt Text<span style={{color: 'red'}}>*</span></label>
                  <input type="text" value={alt_text}
                        onChange={(e) => setAlt_text(e.target.value)}  required name="alt_text" defaultValue className="form-control" id="btn-name" placeholder="Alt Text" />
                </div>
              </div>
              <button  value="Submit" className="btn btn-primary me-2 submit-btn" onClick={savebanner}>Submit <i className="loader mdi mdi-spin hide mdi-loading me-2" /> </button>
              <a href="https://showcase.belgiumwebnet.com/webapi/admin/banner" type="button" className="btn btn-dark btn-sm resetForm">Cancel</a>
            
          </div>
        </div>
      </div>
    </div>
  </div></div>
  </>

  )
}

export default Addbaner