import { React, useEffect, useState } from "react";
import { API_URL, swalalert } from "../Helper";
import axios from "axios";
import { Button } from 'react-bootstrap';
import { useNavigate } from "react-router-dom";



function Addcoupon() {
  const [data, setData] = useState([])
  const [catdata, setCatdata] = useState([])
  const [cust, setCust] = useState(false)
  const [apply, setApply] = useState(false)
  const [minper, setMinper] = useState(false)

  let navigate = useNavigate();
  const [option, setOption] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  const [categ, setCateg] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  const [couponcode, setCouponcode] = useState("");
  const [discounttype, setDicounttype] = useState(1);
  const [entireorder, setEntireorder] = useState("");
  const [discountvalue, setDiscountvalue] = useState("");
  const [minpurchaseamount, setMinpurchaseamount] = useState("");
  const [customerId, setCustomerId] = useState();
  const [limitonepercustomer, setLimitonepercustomer] = useState("");
  const [usagelimits, setUsagelimits] = useState("");
  const [categoryids, setCategoryids] = useState();
  const [startdatetime, setStartdatetime] = useState("");
  const [enddatetime, setEnddatetime] = useState("");

  async function savecoupon() {


    let coupondata = {
      coupon_code: couponcode,
      discount_type: discounttype,
      entire_order: entireorder,
      discount_value: discountvalue,
      min_purchase_amount: minpurchaseamount,
      customerId: customerId,
      limit_one_per_customer: limitonepercustomer,
      usage_limits: usagelimits,
      category_ids: categoryids,
      start_datetime: startdatetime,
      end_datetime: enddatetime
    };

    console.log(coupondata);
    // var parsedata = "";
    // axios.post(`${API_URL}admin/add_coupon`, coupondata).then((res) => {
    //   parsedata = res.data;
    //   if (parsedata.status == 1) {
    //     navigate("/coupon");
    //   } else {
    //     swalalert("danger", parsedata.message);
    //   }

    // });
  }

  function getOptions() {
    let url = `${API_URL}admin/User_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });

    const options = data.map(d => ({
      "value": d.user_id,
      "label": d.first_name
    }))
    setOption({ selectOptions: options })
  }


  function getCateg() {
    let url_cat = `${API_URL}admin/Category_list`;
    axios.get(url_cat).then((res) => {
      const parsedata1 = res.data;
      setCatdata(parsedata1.data)
    });

    const catoptions = catdata.map(d1 => ({
      "value": d1.category_id,
      "label": d1.name
    }))
    setCateg({ selectOptions: catoptions })
  }

  function handleChange(selectedItems) {

    //alert(selectedItems)

    const customer = [];
    for (let i=0; i<selectedItems.length; i++) {
      customer.push(selectedItems[i].value);
    }
    const commaSep = customer.map(item => item).join(', ');
    setCustomerId(commaSep);
    
  }

  function catChange(selectedItems) {

    //alert(selectedItems)

    const categorys = [];
    for (let j=0; j<selectedItems.length; j++) {
      categorys.push(selectedItems[j].value);
    }

    const Catids = categorys.map(item1 => item1).join(', ');
    setCateg(Catids)
  }


  useEffect(() => {

    getOptions()
    getCateg()

  }, [cust, apply,])
console.log(categ)
  
  return (
    <div><div className="page-content page-content-left">
      <div className="row">
        <div className="col-md-12">
          {/* <div className="text-left">
          <h5 className="card-title">Add Coupon</h5>
        </div> */}
        </div>
      </div>

      <div className="row">
        <div className="col-md-12">
          <div className="">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code</label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" value={couponcode}
                        onChange={(e) => setCouponcode(e.target.value)} className="form-control" placeholder="EG:SUMMERSALE" required style={{ textTransform: 'uppercase' }} />
                    </div>

                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{ color: 'red' }} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={1}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" defaultChecked="checked" />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={0}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{ color: 'red' }} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" defaultChecked className="form-check-input entire_order" value={1}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(false)} name="entire_order" id="optionsRadios" />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" value={0}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(true)} />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {apply ? <div id="customer_div" style={{}} data-select2-id="customer_div">
                          {/* <select onChange={(e1) => catChange(e1.target.selectedOptions)} multiple>
                          {categ.selectOptions.map((options, index) => (
                            <option key={index} value={options.value}>{options.label}</option>
                          ))}
                          </select> */}

                          <select  class="form-control" onChange={(e) => catChange(e.target.selectedOptions)} multiple>
                          {categ.selectOptions.map((options, ind) => (
                            <option key={ind} value={options.value}>{options.label}</option>
                          ))}
                        </select>
                      </div> : ""}

                  </div>
        
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" name="discount_value" value={discountvalue}
                    onChange={(e) => setDiscountvalue(e.target.value)} required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />


                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none" defaultChecked="checked" value={0}
                        onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" id="optionsRadios" onClick={() => setMinper(false)}   />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" onClick={() => setMinper(true)} />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  {minper?<input type="number" className="form-control min_purchase_amt" value={minpurchaseamount}
                    onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" placeholder="$ 0.00" min={0} />:""

                  }
                  
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={() => setCust(false)} defaultChecked="checked" />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>


                  <div className="form-check" >
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={() => setCust(true)} />
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">
                        <select class="form-control"  onChange={(e) => handleChange(e.target.selectedOptions)} multiple>
                          {option.selectOptions.map((options, ind) => (
                            <option key={ind} value={options.value}>{options.label}</option>
                          ))}
                        </select>
                     
                        {/* <Select options={option.selectOptions}    onChange={()=>handleChange.bind(this)} /> */}
                      </div> : ""
                    }
                  </div>

                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" value={1}
                        onChange={(e) => setLimitonepercustomer(e.target.value)} name="limit_one_per_customer" id="optionsRadios" />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" value={2}
                        onChange={(e) => setUsagelimits(e.target.value)} name="usage_limits" />
                      Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                {/* { minper?<><div className="form-group col-md-6"><label>&nbsp;</label><input type="number" className="form-control number_of_times" name="usage_limits" placeholder={1} min={0} /></div></>:""} */}
                
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input required type="date" id="start_date" value={startdatetime}
                      onChange={(e) => setStartdatetime(e.target.value)} className="form-control" name="start_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input required type="date" id="end_date" className="form-control" value={enddatetime}
                      onChange={(e) => setEnddatetime(e.target.value)} name="end_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
              </div>


              <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <Button className="btn btn-primary" onClick={savecoupon}>
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    </div>
  )
}


 function Editcoupon(props) {
  const [data, setData] = useState([])
  const [catdata, setCatdata] = useState([])
  const [cust, setCust] = useState(false)
  const [apply, setApply] = useState(false)
  const [minper, setMinper] = useState(false)

  let navigate = useNavigate();
  const [option, setOption] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  const [categ, setCateg] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })
  const ed_data = JSON.parse(props.data);
  // console.log(ed_data.coupon_code)

  const [ecouponcode, setCouponcode] = useState(ed_data.coupon_code);
  const [ediscounttype, setDicounttype] = useState(ed_data.discount_type);
  const [entireorder, setEntireorder] = useState(ed_data.entire_order);
  const [discountvalue, setDiscountvalue] = useState(ed_data.discount_value);
  const [minpurchaseamount, setMinpurchaseamount] = useState(ed_data.min_purchase_amount);
  const [customerId, setCustomerId] = useState(ed_data.customerId);
  const [limitonepercustomer, setLimitonepercustomer] = useState(ed_data.limit_one_per_customer);
  const [usagelimits, setUsagelimits] = useState(ed_data.usage_limits);
  const [categoryids, setCategoryids] = useState(ed_data.category_ids);
  const [startdatetime, setStartdatetime] = useState(ed_data.start_datetime);
  const [enddatetime, setEnddatetime] = useState(ed_data.end_datetime);
  

  async function updatecoupon() {
    let coupondata = {
      id: ed_data.id,
      coupon_code: ecouponcode,
      discount_type: ediscounttype,
      entire_order: entireorder,
      discount_value: discountvalue,
      min_purchase_amount: minpurchaseamount,
      customerId: customerId,
      limit_one_per_customer: limitonepercustomer,
      usage_limits: usagelimits,
      category_ids: categoryids,
      start_datetime: startdatetime,
      end_datetime: enddatetime
    };

    var parsedata = "";
    axios.post(`${API_URL}admin/add_coupon`, coupondata).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        navigate("/coupon");
      } else {
        swalalert("danger", parsedata.message);
      }

    });
  }

  function getOptions() {
    let url = `${API_URL}admin/User_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });

    const options = data.map(d => ({
      "value": d.user_id,
      "label": d.first_name
    }))
    setOption({ selectOptions: options })
  }


  function getCateg() {
    let url = `${API_URL}admin/Category_list`;
    axios.get(url).then((res) => {
      const parsedata1 = res.data;
      setCatdata(parsedata1.data)
    });

    const catoptions = catdata.map(d1 => ({
      "value": d1.category_id,
      "label": d1.name
    }))
    setCateg({ selectOptions: catoptions })
  }
 

var ed_cat =  customerId.split(",");

  useEffect(() => {

    getOptions()
    getCateg()

  }, [cust, apply,])


 
  return (
    <div><div className="page-content page-content-left">
      <div className="row">
        <div className="col-md-12">
          {/* <div className="text-left">
          <h5 className="card-title">Add Coupon</h5>
        </div> */}
        </div>
      </div>

      <div className="row">
        <div className="col-md-12">
          <div className="">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code </label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" value={ecouponcode}
                        onChange={(e) => setCouponcode(e.target.value)} className="form-control" placeholder="EG:SUMMERSALE" required style={{ textTransform: 'uppercase' }} />
                    </div>

                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{ color: 'red' }} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={1}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" checked={ ediscounttype == 1 ? "checked":"" } />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={0}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" checked={ ediscounttype == 0 ? "checked":"" } />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{ color: 'red' }} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" defaultChecked className="form-check-input entire_order" value={1}
                        onChange={(e) => setEntireorder(e.target.value)} checked={ entireorder == 1 ? "checked":"" } name="entire_order" id="optionsRadios" />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" value={2}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(true)}  checked={ entireorder == 2 ? "checked":"" } />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {entireorder == 2 ? <select class="form-control" onChange={(e) => setCategoryids(e.target.value)} multiple>
                      {categ.selectOptions.map((options, index) => (
                        <option key={index} value={options.value}  selected={categoryids == options.value ? "selected":""} >{options.label}</option>
                      ))}</select> : ""}

                  </div>
               
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" name="discount_value" value={discountvalue}
                    onChange={(e) => setDiscountvalue(e.target.value)} required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />


                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none"  value={0}
                        onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" id="optionsRadios" onClick={() => setMinper(false)} checked={ minpurchaseamount == 0 && minper == false ? "checked":"" } />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" onClick={() => setMinper(true)}   checked={ minpurchaseamount != 0 && minper? "checked" :"" } />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  {minper?<input type="number" className="form-control min_purchase_amt" value={minpurchaseamount}
                    onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" placeholder="$ 0.00" min={0} />:""

                  }
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={() => setCust(false)} checked={ customerId == "" ? "checked":"" } />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>


                  <div className="form-check" >
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={() => setCust(true)} checked={ customerId != "" ? "checked":"" }/>
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">


                        <select class="form-control" onChange={(e) => setCustomerId(e.target.value)} multiple>
                          {option.selectOptions.map((options, ind) => (
                            <option key={ind} value={options.value} >{options.label}</option>
                          ))}
                        </select>
                        {/* <Select options={option.selectOptions}    onChange={()=>handleChange.bind(this)} /> */}
                      </div> : ""
                    }
                  </div>

                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" value={1}
                        onChange={(e) => setLimitonepercustomer(e.target.value)} name="limit_one_per_customer" id="optionsRadios" />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" value={2}
                        onChange={(e) => setUsagelimits(e.target.value)} name="usage_limits" />
                      Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label>&nbsp;</label>
                  <input type="number" className="form-control number_of_times" name="usage_limits" placeholder={1} min={0} style={{ display: 'none' }} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input required type="date" id="start_date" value={startdatetime}
                      onChange={(e) => setStartdatetime(e.target.value)} className="form-control" name="start_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input required type="date" id="end_date" className="form-control" value={enddatetime}
                      onChange={(e) => setEnddatetime(e.target.value)} name="end_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
              </div>


              <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <Button className="btn btn-primary" onClick={updatecoupon}>
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    </div>
  )
}

export {Addcoupon,Editcoupon} 