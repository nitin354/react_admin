
import "bootstrap/dist/css/bootstrap.min.css";
import "./css/sidebar.css";
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { BrowserRouter, Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Coustomerlist from "./components/Coustomerlist";
import 'jquery/dist/jquery.min.js';

//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import Appointment from "./components/Appointment";
import Category from "./components/Category";
import Couponlist from "./components/Couponlist";
import Bannerlist from "./components/Bannerlist";



function App() {
  let user_info = localStorage.getItem("user_info")
    ? true
    : false;


  return (
    <div className="App">
      <div>
        <BrowserRouter>
          <Routes>
          <Route exact path="/" element={user_info? <Navigate to="/dashboard" replace /> :<Login />} />
            
            <Route exact path="/dashboard" element={<Dashboard />} />
            <Route exact path="/customers" element={user_info?<Coustomerlist />:<Navigate to="/" replace/>}/>
            <Route exact path="/appointments" element={user_info?<Appointment />:<Navigate to="/" replace/>}/>
            <Route exact path="/category" element={user_info?<Category />:<Navigate to="/" replace/>}/>
            <Route exact path="/coupon" element={user_info?<Couponlist />:<Navigate to="/" replace/>}/>
            <Route exact path="/banner" element={user_info?<Bannerlist />:<Navigate to="/" replace/>}/>
          </Routes>
        </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
