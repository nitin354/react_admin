
import "bootstrap/dist/css/bootstrap.min.css";
import "./css/sidebar.css";
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import { BrowserRouter, Route, Routes,useNavigate } from "react-router-dom";
import Header from "./components/Header";
import Coustomerlist from "./components/Coustomerlist";
import 'jquery/dist/jquery.min.js';
 
//Datatable Modules
import "datatables.net-dt/js/dataTables.dataTables"
import "datatables.net-dt/css/jquery.dataTables.min.css"
import Appointment from "./components/Appointment";


function App() {
  let user_info = localStorage.getItem("user_info")
  ? JSON.parse(localStorage.getItem("user_info"))
  : "";
   
   
  return (
    <div className="App">
      <div>
        <BrowserRouter>
          {user_info.length == 0 ? "":<Header/>}
          
          <Routes>
          <Route path="/" element={<Login />} />
            <Route
              exact
              path="/dashboard"
              element={<Dashboard />}
            />
             <Route
              exact
              path="/customers"
              element={<Coustomerlist />}
            />

            <Route
              exact
              path="/appointments"
              element={<Appointment />}
            />
          </Routes>
          

        </BrowserRouter>
     
      </div>

    </div>
  );
}

export default App;
