import React from 'react'
import { Link } from "react-router-dom";

function Sidebar() {

    var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
  return (
    <div><div className="sidenav">
      <Link to="/dashboard">Dashboard</Link>
    <Link to="/customers">Customers</Link>
    <Link to="/appointments">Appointments</Link>
    <a href="#services">appointments</a>
    <a href="#clients">Clients</a>
    <a href="#contact">Contact</a>
    <button className="dropdown-btn">Dropdown 
      <i className="fa fa-caret-down" />
    </button>
    <div className="dropdown-container">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
    <a href="#contact">Search</a>
  </div>
  </div>
  )
}

export default Sidebar