import React from 'react'
import { Link } from "react-router-dom";

function Sidebar() {

    var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}
  return (
    <div><div className="sidenav">
      <Link to="/dashboard">Dashboard</Link>
    <Link to="/customers">Customers</Link>
    <Link to="/appointments">Appointments</Link>
    <Link to="/category">Category</Link>

    category
   
  </div>
  </div>
  )
}

export default Sidebar