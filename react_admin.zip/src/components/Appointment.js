import {React,useEffect,useState} from 'react'
import Appointlist from './Appointlist';
import { API_URL } from "../Helper";
import axios from "axios";
import {  Tab,Tabs } from "react-bootstrap";

function Appointment() {
    const [data, setData] = useState([])
    const [closedata, setClosedata] = useState([])
    const [canceldata, setCanceldata] = useState([])
    const [key, setKey] = useState('home');

    useEffect(() => {
        let url = `${API_URL}/admin/appointment_list`;

        axios.get(url).then((res) => {
          const parsedata = res.data;
         //
          setData(parsedata.data.new_list)
          setClosedata(parsedata.data.closed_list)
          setCanceldata(parsedata.data.cancelled_list)

        });

    }, [data,closedata,canceldata,key])
    

        return (
            <div className='container my5'>
                <h3 className='my5'>Appointments</h3>
          <Tabs
            id="controlled-tab-example"
            activeKey={key}
            onSelect={(k) => setKey(k)}
            className="mb-3 my5"
          >
            <Tab eventKey="home" title="New Appointment">
              <Appointlist  type="new"  data={data}/>
            </Tab>
            <Tab eventKey="profile" title="Close Appointment">
            <Appointlist type="closed" data={closedata} />
            </Tab>
            <Tab eventKey="contact"  title="Cancel Appintment" >
            <Appointlist  type="cancel"  data={canceldata} />
            </Tab>
          </Tabs>
          </div>
        );
      
 
}

export default Appointment