import {React,useEffect,useState} from 'react';
import { Card, Button,Modal } from "react-bootstrap";
import { API_URL } from "../Helper";
import axios from "axios";
import Cardcount from './Cardcount';

function Dashboard() {

  const [customers, setCustomers] = useState(0)
  const [orders, setOrders] = useState(0)
  const [jewelry, setJewelry] = useState(0)
  const [appointments, setAppointments] = useState(0)
  const [naturaldiamonds, setNaturaldiamonds] = useState(0)
  const [labdiamonds, setLabdiamonds] = useState(0)
  const [fancydiamonds, setFancydiamonds] = useState(0)
  const [gemstones, setGemstones] = useState(0)
  const [reviews, setReviews] = useState(0)
  const [blogs, setBlogs] = useState(0)
  const [tab, settab] = useState([])
  const [apppointment, setAppointment] = useState([])
  const [order, setOrder] = useState([])

  useEffect(() => {
   
    let url = `${API_URL}admin/dashboard`;
  
    axios.get(url).then((res) => {
      const parsedata = res.data;

     if(parsedata.status == 1){ 
      setAppointment(parsedata.data.appointmentsList);
      setOrder(parsedata.data.ordersList)
      settab(parsedata.data)
      setCustomers(parsedata.data.customers)
      setOrders(parsedata.data.orders)
      setJewelry(parsedata.data.jewelry)
      setAppointments(parsedata.data.appointments)
      setNaturaldiamonds(parsedata.data.naturaldiamonds)
      setLabdiamonds(parsedata.data.labdiamonds)
      setFancydiamonds(parsedata.data.fancydiamonds)
      setGemstones(parsedata.data.gemstones)
      setReviews(parsedata.data.reviews)
      setBlogs(parsedata.data.blogs)
      
     }
 
      
    });
  }, [])

  return (
    <div>Dashborad
      <div className='container'>


      <div className='row'>

      <div className='col-md-3 my-2'>
      <Cardcount name={"Customers"} count={customers}/>
     </div>

     <div className='col-md-3 my-2'>
      <Cardcount name={"orders"} count={orders}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"jewelry"} count={jewelry}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"appointments"} count={appointments}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"natural diamonds"} count={naturaldiamonds}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"lab diamonds"} count={labdiamonds}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"fancy diamonds"} count={fancydiamonds}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"gemstones"} count={gemstones}/>
     </div>
     <div className='col-md-3 my-2'>
      <Cardcount name={"reviews"} count={reviews}/>
     </div>

     <div className='col-md-3 my-2'>
      <Cardcount name={"blogs"} count={blogs}/>
     </div>
     </div>

     <div className='row my-5'>
     
     <div className='col-md-6'>
     <h3 className="text-center" >Appointments</h3>
       <table id="example" class="table table-hover table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Comment</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        {apppointment && apppointment.map((result,index) => {
          return (
               <tr>
                <td>{index+1}</td>
                <td>{result.first_name +" "+result.last_name}</td>
                <td>{result.comment}</td>
                <td><Button variant="primary" > View </Button></td>
                
              </tr>
          )
        })}
          
           
        </tbody>
      </table>
      </div>
       
      <div className='col-md-6'>
     <h3 className="text-center" >Orders</h3>
       <table id="example1" class="table table-hover table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>status</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        {order && order.map((result1) => {
          if(result1.order_status==0)
          { 
            var status = "pending";
          }else if(result1.order_status==1)
          { 
            var status = "Completed";
          } 
          return (
               <tr>
                <td>{result1.order_id}</td>
                <td>{result1.first_name +" "+result1.last_name}</td>
                <td> {status} </td>
                <td>{result1.created_at}</td>
                <td><Button variant="primary" > View </Button></td>
                
              </tr>
          )
        })}
          
           
        </tbody>
      </table>
      </div>


      </div>

       </div>
    </div>

  )
}

export default Dashboard