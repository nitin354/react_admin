import React from 'react'
import { Card, Button } from "react-bootstrap";
function Cardcount(props) {

  return (<div> <Card><Card.Body >
    <Card.Title className='text-center'>{props.name.toUpperCase()}</Card.Title>
    <Card.Text className='text-center'>
      {props.count}
    </Card.Text>
  </Card.Body>
  </Card></div>)
}

export default Cardcount