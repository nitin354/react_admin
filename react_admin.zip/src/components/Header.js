import React, {  useEffect } from "react";
import { Navbar, NavDropdown, Container, Nav, Dropdown } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import Sidebar from "./Sidebar";

//import { cartContext } from '../Context/cartcontext';
// import { FaCartPlus,FaRegHeart } from 'react-icons/fa';
export default function Header(props) {
 
  let user_info = localStorage.getItem("user_info")
    ? JSON.parse(localStorage.getItem("user_info"))
    : "";
  const redirect = useNavigate();

  useEffect(() => {
    user_info.length == 0 ? redirect("/") : redirect("/dashboard");

  }, []);

  function logout() {
    localStorage.setItem("user_info", "");
    redirect("/");
  }
 
  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container>
          <Navbar.Brand>
            <Link to="/">Ni3 jewels</Link>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            
            {user_info ? (
              <NavDropdown
                id="nav-dropdown-dark-example"
                title={user_info.name.toUpperCase()}
                menuVariant="dark"
              >
                <NavDropdown.Item onClick={logout}>Logout</NavDropdown.Item>
              </NavDropdown>
            ) : (
              <Link className="navbar-dark navbar-brand" to="/">
                Login
              </Link>
            )}
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <Sidebar/> 
    </div>
  );
}
