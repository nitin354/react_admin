import { React,useEffect,useState } from "react";
import { API_URL } from "../Helper";
import axios from "axios";
import Select from 'react-select'


function Addcoupon() {
    const [data, setData] = useState([])
    const [catdata, setCatdata] = useState([])
    const [cust, setCust] = useState(false)
    const [apply, setApply] = useState(false)
    const [option, setOption] = useState({ selectOptions : [],
        id: "",
        name: ''})

    const [categ, setCateg] = useState({ selectOptions : [],
            id: "",
            name: ''})

            

    function getOptions(){
        let url = `${API_URL}admin/User_list`;
        axios.get(url).then((res) => {
          const parsedata = res.data;
          setData(parsedata.data)
        });
    
        const options = data.map(d => ({
          "value" : d.user_id,
          "label" : d.first_name
        }))
        setOption({selectOptions: options})
      }


      function getCateg(){
        let url = `${API_URL}admin/Category_list`;
        axios.get(url).then((res) => {
          const parsedata1 = res.data;
          console.log(parsedata1.data);
          setCatdata(parsedata1.data)
        });
    
        const catoptions = catdata.map(d1 => ({
          "value" : d1.category_id,
          "label" : d1.name
        }))
        setCateg({selectOptions: catoptions})
      }

      function handleChange(e){
        setOption({id:e.value, name:e.label})
       }

       function cathandleChange(e){
        setCateg({id:e.value, name:e.label})
       }


    useEffect(() => {

        getOptions()
        getCateg()
         
    }, [cust,apply])
    // console.log(cust)
    var op ="";
  return (
    <div><div className="page-content page-content-left">
    <div className="row">
      <div className="col-md-12">
        {/* <div className="text-left">
          <h5 className="card-title">Add Coupon</h5>
        </div> */}
      </div>
    </div>
    <form action="https://admin.belgiumwebnet.com/admin/Coupon/add_coupon" method="POST" className="forms-sample" encType="multipart/form-data" data-select2-id={9}>
      <div className="row">
        <div className="col-md-12">
          <div className="card">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code</label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" className="form-control" defaultValue placeholder="EG:SUMMERSALE"   required style={{textTransform: 'uppercase'}} />
                    </div>
                    <div className="col" style={{maxWidth: '160px'}}>
                      <input type="button" id="button" className="btn btn-light" defaultValue="Generate Code" onclick="getElementById('coupon_code').value=Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);" />
                      <input type="hidden" name="product" id="product" defaultValue />
                      <input type="hidden" name="customer" id="customer" defaultValue />
                      <input type="hidden" name="offer_id" id="offer_id" defaultValue />
                      <small style={{color: 'red'}} />
                    </div>
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{color: 'red'}} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" id="optionsRadios" defaultValue={1} defaultChecked="checked" />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" id="optionsRadios" defaultValue={0} />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{color: 'red'}} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" defaultChecked className="form-check-input entire_order" name="entire_order" id="optionsRadios" defaultValue={1} />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" onClick={()=>setApply(true)} defaultValue={2} />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                      { apply?<Select options={categ.selectOptions}   onChange={()=>handleChange.bind(this)} isMulti/>:""

                      }
                      
                  </div>
                  {/* <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input prod_custwise" name="entire_order" defaultValue={4} />
                      Specific Product
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div> */}
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" defaultValue name="discount_value" required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />
                  <div className="Categories" style={{display: 'none'}}>
                    <label>Select Categories</label>
                    <select className="js-example-basic-multiple w-100 select2-hidden-accessible" multiple data-width="100%" name="category_ids[]" data-select2-id={3} tabIndex={-1} aria-hidden="true">
                      <option value>Select Categories</option>
                      <option value={16}>test</option><option value={15}>Watches</option><option value={14}>Fashion Rings</option><option value={13}>Pendants</option><option value={9}>Fine Jewelry</option><option value={8}>Wedding Rings And Bands</option><option value={5}>Earrings</option><option value={4}>Necklaces</option><option value={3}>Bracelets</option><option value={2}>Engagement Rings</option> </select><span className="select2 select2-container select2-container--default" dir="ltr" data-select2-id={4} style={{width: '100%'}}><span className="selection"><span className="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabIndex={-1} aria-disabled="false"><ul className="select2-selection__rendered"><li className="select2-search select2-search--inline"><input className="select2-search__field" type="search" tabIndex={0} autoComplete="off" autoCorrect="off" autoCapitalize="none" spellCheck="false" role="searchbox" aria-autocomplete="list" placeholder style={{width: '0.75em'}} /></li></ul></span></span><span className="dropdown-wrapper" aria-hidden="true" /></span>
                  </div>
                  <div className="products" style={{display: 'none'}}>
                    <label>Select Product</label>
                    <select id="selproduct" data-width="100%" name="product" data-select2-id="selproduct" tabIndex={-1} className="select2-hidden-accessible" aria-hidden="true">
                      <option value data-select2-id={2}>Select Product </option>
                    </select><span className="select2 select2-container select2-container--default" dir="ltr" data-select2-id={1} style={{width: '100%'}}><span className="selection"><span className="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabIndex={0} aria-disabled="false" aria-labelledby="select2-selproduct-container"><span className="select2-selection__rendered" id="select2-selproduct-container" role="textbox" aria-readonly="true" title="Select Product ">Select Product </span><span className="select2-selection__arrow" role="presentation"><b role="presentation" /></span></span></span><span className="dropdown-wrapper" aria-hidden="true" /></span>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none" defaultChecked="checked" name="min_purchase_amount" id="optionsRadios" defaultValue={0} />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <input type="number" className="form-control min_purchase_amt" name="min_purchase_amount" placeholder="$ 0.00" min={0} style={{display: 'none'}} />
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={()=>setCust(false)}  defaultValue="everyone" defaultChecked="checked" />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>

                  
                  <div className="form-check" data-select2-id={8}>
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={()=>setCust(true)} defaultValue="single"  />
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                       { cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">
                      <label>Select Customer<i className="input-frame" /></label>
                       <Select options={option.selectOptions}   onChange={()=>handleChange.bind(this)} isMulti/>
                       </div>:""
                    }
                  </div>
                   
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" name="limit_one_per_customer" id="optionsRadios" defaultValue={1} />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" name="usage_limits" />
                      Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label>&nbsp;</label>
                  <input type="number" className="form-control number_of_times" name="usage_limits" placeholder={1} min={0} style={{display: 'none'}} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input required type="date" id="start_date" className="form-control" name="start_datetime" autoComplete="off" />
                  
                    <small style={{color: 'red'}} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input required type="date" id="end_date" className="form-control" name="end_datetime" autoComplete="off" />
                    <small style={{color: 'red'}} />
                  </div>
                </div>
                <div className="form-group col-md-6" style={{marginTop: '30px'}}>
                  <div className="form-group col-md-6 form-check form-check-flat form-check-primary send_email" />
                </div>
              </div>
              {/* <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <button type="submit" className="submit-btn btn-primary mt-2 mr-2">Submit</button>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </div>
    </form>
  </div>
  </div>
  )
}

export default Addcoupon