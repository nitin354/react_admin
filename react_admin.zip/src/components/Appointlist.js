import {React,useEffect} from 'react';

import { Button } from "react-bootstrap";

import $ from 'jquery'; 

function Appointlist(props) {

    useEffect(() => {
        $(document).ready(function () {
            setTimeout(function(){
            $('#example').DataTable();
             } ,1000);
        });
    }, [])
    
  return (

     
    <div className="container">
         
        <table id="example" class="table table-hover table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        {props.data && props.data.map((result,index) => {
            
          return (
               <tr>
                <td>{index+1}</td>
                <td>{result.first_name +" "+result.last_name}</td>
                <td>{result.phone}</td>
                <td>{result.email}</td>
                {/* <td>{{result.status ==1?<Button variant="primary" > Cancel </Button><Button variant="info" > Close </Button></>:""}}</td> */}
                {/* <td> if(result.status ==1){
               <><Button variant="primary" > Cancel </Button><Button variant="info" > Close </Button></>
                }else if(result.status == 2){
                    <><Button variant="primary" > Cancel </Button></>
                }else if(result.status == 3){
                    <><Button variant="primary" > close </Button></>
                } </td> */}
            
               
              </tr>
          )
        })}
          
           
        </tbody>
      </table>
         
      </div>
    
  )
}

export default Appointlist