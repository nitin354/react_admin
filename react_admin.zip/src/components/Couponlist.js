import  {React,useEffect,useState} from 'react';
import { Button,Modal } from "react-bootstrap";
import { API_URL } from "../Helper";
import axios from "axios";
import Header from "../components/Header";
import $ from 'jquery';
import Addcoupon from './Addcoupon';

function Couponlist() {


    const [data, setData] = useState([])
    
    // modal show open
    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    // modal show End

    
    useEffect(() => {
        let url = `${API_URL}admin/Coupon_list`;
        axios.get(url).then((res) => {
          const parsedata = res.data;
          setData(parsedata.data)
        });

        $(document).ready(function () {
            setTimeout(function(){
                $('#coupon').DataTable();
                 } ,1000);
          });

    }, [])

  return (
    <div>
        <Header />
        <div className="jumbotron text-center my-5">
        <h3>Couponlist</h3>
      </div>
      <div className="text-center my-5">
      <Button variant="primary" className='text-center' onClick={handleShow}>
        Add Coupon
      </Button>
      </div>

      <Modal show={show} onHide={handleClose} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Add Coupon</Modal.Title>
        </Modal.Header>
        <Modal.Body><Addcoupon/></Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
         <div className="container my-5">
       
         

<table id="coupon" className="table table-hover table-bordered">
  <thead>
    <tr>
      <th>ID</th>
      <th>Coupone Code</th>
      <th>Dicount</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Status</th>
      {/* <th>Action</th> */}
    </tr>
  </thead>
  <tbody>
    {data && data.map((result, index) => {

    //   if (data.status === "new") {
    //     var btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.appointment_id, 3)} > Cancel </Button><Button className='mx-2' variant="info" onClick={() => update_status(result.appointment_id, 2)} > Close </Button></>;
    //   } else if (props.type === "closed") {
    //     btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.appointment_id, 3)} > Cancel </Button><Button className='mx-2' variant="info" onClick={() => update_status(result.appointment_id, 1)} > New </Button></>
    //   } else {

    //     btn = <><Button variant="primary" className='mx-2' onClick={() => update_status(result.appointment_id, 2)}> Close </Button><Button className='mx-2' variant="info" onClick={() => update_status(result.appointment_id, 1)} > New </Button></>

    //   }

      return (
        <tr key={result.id}>
          <td>{index + 1}</td>
          <td>{result.coupon_code}</td>
          <td>{result.discount_value}</td>
          <td>{result.start_datetime}</td>
          <td>{result.end_datetime}</td>
          <td>{result.status}</td>
          {/* <td>{btn}</td> */}



        </tr>
      )
    })}


  </tbody>
</table>

</div>
    </div>
    
  )
}

export default Couponlist