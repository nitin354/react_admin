

 export const API_URL = "https://showcase.belgiumwebnet.com/webapi/api/";
 export const BANNER_URL = "https://showcase.belgiumwebnet.com/webapi/assets/images/home/frontslider/";

