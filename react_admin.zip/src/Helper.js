

 export const API_URL = "https://showcase.belgiumwebnet.com/webapi/api/";

