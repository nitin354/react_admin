import { React, useEffect, useState } from "react";
import { API_URL, swalalert } from "../Helper";
import axios from "axios";
import { Button } from 'react-bootstrap';
import { useNavigate,useParams } from "react-router-dom";
import Sidebar from './Sidebar';
import Select from "react-select";


function Addcoupon() {
  const [data, setData] = useState([])
  const [catdata, setCatdata] = useState([])
  const [cust, setCust] = useState(false)
  const [apply, setApply] = useState(false)
  const [minper, setMinper] = useState(false)
  const [usage, setUsage] = useState(false)

  let navigate = useNavigate();
  const [option, setOption] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  const [categ, setCateg] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  const [couponcode, setCouponcode] = useState("");
  const [discounttype, setDicounttype] = useState(1);
  const [entireorder, setEntireorder] = useState("");
  const [discountvalue, setDiscountvalue] = useState("");
  const [minpurchaseamount, setMinpurchaseamount] = useState("");
  const [customerId, setCustomerId] = useState();
  const [limitonepercustomer, setLimitonepercustomer] = useState("");
  const [usagelimits, setUsagelimits] = useState("");
  const [categoryids, setCategoryids] = useState();
  const [startdatetime, setStartdatetime] = useState("");
  const [enddatetime, setEnddatetime] = useState("");

  async function savecoupon() {


    let coupondata = {
      coupon_code: couponcode,
      discount_type: discounttype,
      entire_order: entireorder,
      discount_value: discountvalue,
      min_purchase_amount: minpurchaseamount,
      customerId: customerId,
      limit_one_per_customer: limitonepercustomer,
      usage_limits: usagelimits,
      category_ids: categoryids,
      start_datetime: startdatetime,
      end_datetime: enddatetime
    };

    console.log(coupondata);
    var parsedata = "";
    axios.post(`${API_URL}admin/add_coupon`, coupondata).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        //navigate("/coupon");
      } else {
        swalalert("danger", parsedata.message);
      }

    });
  }

  function getOptions() {
    let url = `${API_URL}admin/User_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });

    // const options = data.map(d => ({
    //   "value": d.user_id,
    //   "label": d.first_name
    // }))
    // setOption({ selectOptions: options })
  }


  function getCateg() {
    let url_cat = `${API_URL}admin/Category_list`;
    axios.get(url_cat).then((res) => {
      const parsedata1 = res.data;
      setCatdata(parsedata1.data)
    });

    // const catoptions = catdata.map(d1 => ({
    //   "value": d1.category_id,
    //   "label": d1.name
    // }))
    // setCateg({ selectOptions: catoptions })
  }

  function handleChange(e) {

    //alert(selectedItems)

    // const customer = [];
    // for (let i=0; i<selectedItems.length; i++) {
    //   customer.push(selectedItems[i].value);
    // }
    // const commaSep = customer.map(item => item).join(', ');
    // setCustomerId(commaSep);

    setCustomerId(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
    
  }

  function catChange(e) {

    //alert(selectedItems)

 

    //const Catids = categorys.map(item1 => item1).join(', ');
    //setCateg(Catids)
    setCategoryids(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
  }

var catoptions = [];
var useroptions = [];


  useEffect(() => {

    getOptions()
    getCateg()

  }, [cust, apply])
console.log(categ)
  
  return (
    <>
      <Sidebar />
      <div className='container my-5'><div className=" text-center my-5">
        <h3>Add Banner</h3>
      </div>
    <div><div className="page-content page-content-left">
      <div className="row">
        <div className="col-md-12">
          {/* <div className="text-left">
          <h5 className="card-title">Add Coupon</h5>
        </div> */}
        </div>
      </div>

      <div className="row">
        <div className="col-md-12">
          <div className="card">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code</label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" value={couponcode}
                        onChange={(e) => setCouponcode(e.target.value)} className="form-control" placeholder="EG:SUMMERSALE" required style={{ textTransform: 'uppercase' }} />
                    </div>

                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{ color: 'red' }} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={1}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" defaultChecked="checked" />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={0}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{ color: 'red' }} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" defaultChecked className="form-check-input entire_order" value={1}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(false)} name="entire_order" id="optionsRadios" />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" value={0}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(true)} />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {apply ? <div id="customer_div" style={{}} data-select2-id="customer_div">
                          {/* <select onChange={(e1) => catChange(e1.target.selectedOptions)} multiple>
                          {categ.selectOptions.map((options, index) => (
                            <option key={index} value={options.value}>{options.label}</option>
                          ))}
                          </select> */}

                          {/* <select  class="form-control" onChange={(e) => catChange(e.target.selectedOptions)} multiple>
                          {categ.selectOptions.map((options, ind) => (
                            <option key={ind} value={options.value}>{options.label}</option>
                          ))}
                        </select> */}
                        { catdata.map((element) => {
                          if(element.name != null  ){
                             catoptions.push( {value: element.category_id ,label : element.name } );
                          }
                    })   
                   
                    }

                   
                    
                    <Select  isMulti  options={catoptions}   onChange={catChange}  />

                        {/* <Select options={option.selectOptions}    onChange={()=>handleChange.bind(this)} /> */}
                      </div> : ""}

                  </div>
        
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" name="discount_value" value={discountvalue}
                    onChange={(e) => setDiscountvalue(e.target.value)} required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none" defaultChecked="checked" value={0}
                        onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" id="optionsRadios" onClick={() => setMinper(false)}   />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" onClick={() => setMinper(true)} />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  {minper?<input type="number" className="form-control min_purchase_amt" value={minpurchaseamount}
                    onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" placeholder="$ 0.00" min={0} />:""

                  }
                  
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={() => setCust(false)} defaultChecked="checked" />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>


                  <div className="form-check" >
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={() => setCust(true)} />
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">
                        {/* <select class="form-control"  onChange={(e) => handleChange(e.target.selectedOptions)} multiple>
                          {option.selectOptions.map((options, ind) => (
                            <option key={ind} value={options.value}>{options.label}</option>
                          ))}
                        </select> */}

                        {

                     
                          data.map((element) => {
                          if(element.first_name != null  ){
                            useroptions.push( {value: element.user_id ,label : element.first_name } );
                          }
                    })   
                        }

                        
                     
                        <Select isMulti options={useroptions} value={data.filter(obj => categoryids.includes(obj.value))} onChange={handleChange}/>
                      </div> : ""
                    }
                  </div>

                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" value={1}
                        onChange={(e) => setLimitonepercustomer(e.target.value)} name="limit_one_per_customer" id="optionsRadios" />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" value={2}
                         name="usage_limits" />
                      Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                { minper?<><div className="form-group col-md-6"><label>&nbsp;</label><input type="number" onChange={(e) => setUsagelimits(e.target.value)} className="form-control number_of_times" name="usage_limits" placeholder={1} min={0} /></div></>:""}
                
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input required type="date" id="start_date" value={startdatetime}
                      onChange={(e) => setStartdatetime(e.target.value)} className="form-control" name="start_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input required type="date" id="end_date" className="form-control" value={enddatetime}
                      onChange={(e) => setEnddatetime(e.target.value)} name="end_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
              </div>


              <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <Button className="btn btn-primary" onClick={savecoupon}>
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    </div>
    </div>
    </>
  )
}


 function Editcoupon() {
  const [data, setData] = useState([])
  const [catdata, setCatdata] = useState([])
  const [cust, setCust] = useState(false)
  const [apply, setApply] = useState(false)
  const [minper, setMinper] = useState(false)

  let navigate = useNavigate();
  const [option, setOption] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  const [categ, setCateg] = useState({
    selectOptions: [],
    id: "",
    name: ""
  })

  // console.log(ed_data.coupon_code)

  const [ecouponcode, setCouponcode] = useState("");
  const [ediscounttype, setDicounttype] = useState("");
  const [entireorder, setEntireorder] = useState("");
  const [discountvalue, setDiscountvalue] = useState("");
  const [minpurchaseamount, setMinpurchaseamount] = useState("");
  const [customerId, setCustomerId] = useState("");
  const [limitonepercustomer, setLimitonepercustomer] = useState("");
  const [usagelimits, setUsagelimits] = useState("");
  const [categoryids, setCategoryids] = useState("");
  const [startdatetime, setStartdatetime] = useState("");
  const [enddatetime, setEnddatetime] = useState("");
  
const {coupon_id} = useParams()
  async function updatecoupon() {
    let coupondata = {
      id: coupon_id,
      coupon_code: ecouponcode,
      discount_type: ediscounttype,
      entire_order: entireorder,
      discount_value: discountvalue,
      min_purchase_amount: minpurchaseamount,
      customerId: customerId,
      limit_one_per_customer: limitonepercustomer,
      usage_limits: usagelimits,
      category_ids: categoryids,
      start_datetime: startdatetime,
      end_datetime: enddatetime
    };

    var parsedata = "";
    axios.post(`${API_URL}admin/add_coupon`, coupondata).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {
        navigate("/coupon");
      } else {
        swalalert("danger", parsedata.message);
      }

    });
  }

  function getOptions() {
    let url = `${API_URL}admin/User_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });

    // const options = data.map(d => ({
    //   "value": d.user_id,
    //   "label": d.first_name
    // }))
    // setOption({ selectOptions: options })
  }


  function getCateg() {
    let url_cat = `${API_URL}admin/Category_list`;
    axios.get(url_cat).then((res) => {
      const parsedata1 = res.data;
      setCatdata(parsedata1.data)
    });

    // const catoptions = catdata.map(d1 => ({
    //   "value": d1.category_id,
    //   "label": d1.name
    // }))
    // setCateg({ selectOptions: catoptions })
  }

  function handleChange(e) {

    //alert(selectedItems)

    // const customer = [];
    // for (let i=0; i<selectedItems.length; i++) {
    //   customer.push(selectedItems[i].value);
    // }
    // const commaSep = customer.map(item => item).join(', ');
    // setCustomerId(commaSep);

    setCustomerId(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
    
  }

  function catChange(e) {

    //alert(selectedItems)

 

    //const Catids = categorys.map(item1 => item1).join(', ');
    //setCateg(Catids)
    setCategoryids(Array.isArray(e)?e.map(x=>x.value).join(','):[]);
  }

var catoptions = [];
var useroptions = [];


  useEffect(() => {
    let item = {id:coupon_id}
    var parsedata = "";
    axios.post(`${API_URL}admin/coupon_detail`, item).then((res) => {
      parsedata = res.data;
      if (parsedata.status == 1) {

        setCouponcode(parsedata.data.coupon_code);
        setDicounttype(parsedata.data.discount_type);
        setEntireorder(parsedata.data.entire_order);
        setDiscountvalue(parsedata.data.discount_value);
        setMinpurchaseamount(parsedata.data.min_purchase_amount);
        setCustomerId(parsedata.data.customerId);
        setLimitonepercustomer(parsedata.data.limit_one_per_customer);
        setUsagelimits(parsedata.data.usage_limits);
        setCategoryids(parsedata.data.category_ids);
        setStartdatetime(parsedata.data.start_datetime);
        setEnddatetime(parsedata.data.end_datetime);
        //navigate("/coupon");
      } else {
        swalalert("danger", parsedata.message);
      }

    });

    getOptions()
    getCateg()

  }, [cust, apply,])


 
  return (
    <>
      <Sidebar />
      <div className='container my-5'><div className=" text-center my-5">
        <h3>Add Banner</h3>
      </div>
    <div><div className="page-content page-content-left">
      <div className="row">
        <div className="col-md-12">
          {/* <div className="text-left">
          <h5 className="card-title">Add Coupon</h5>
        </div> */}
        </div>
      </div>

      <div className="row">
        <div className="col-md-12">
          <div className="">
            <div className="card-body">
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Coupon Code </label>
                  <div className="row">
                    <div className="col">
                      <input type="text" id="coupon_code" name="coupon_code" value={ecouponcode}
                        onChange={(e) => setCouponcode(e.target.value)} className="form-control" placeholder="EG:SUMMERSALE" required style={{ textTransform: 'uppercase' }} />
                    </div>

                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Types</label><br />
                  <small style={{ color: 'red' }} />
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={1}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" checked={ ediscounttype == 1 ? "checked":"" } />
                      Fixed Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check form-check-inline">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input no_discout_val" name="discount_type" value={0}
                        onChange={(e) => setDicounttype(e.target.value)} id="optionsRadios" checked={ ediscounttype == 0 ? "checked":"" } />
                      Percentage
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group applies_to col-md-6">
                  <label htmlFor="exampleInputUsername1 ">Applies To</label>
                  <small style={{ color: 'red' }} />
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" defaultChecked className="form-check-input entire_order" value={1}
                        onChange={(e) => setEntireorder(e.target.value)} checked={ entireorder == 1 ? "checked":"" } name="entire_order" id="optionsRadios" />
                      Entire Order
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input specific_cat" name="entire_order" value={2}
                        onChange={(e) => setEntireorder(e.target.value)} onClick={() => setApply(true)}  checked={ entireorder == 2 ? "checked":"" } />
                      Specific Categories
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {entireorder == 2 ? <select class="form-control" onChange={(e) => setCategoryids(e.target.value)} multiple>
                      {categ.selectOptions.map((options, index) => (
                        <option key={index} value={options.value}  selected={categoryids == options.value ? "selected":""} >{options.label}</option>
                      ))}</select> : ""}

                  </div>
               
                </div>
                <div className="form-group dis_val col-md-6">
                  <label htmlFor="exampleInputUsername1">Discount Value</label>
                  <input type="text" className="form-control" name="discount_value" value={discountvalue}
                    onChange={(e) => setDiscountvalue(e.target.value)} required autoComplete="off" placeholder="Set Value for Selected Type" min={0} />
                  <br />


                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Minimum Requirements</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none"  value={0}
                        onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" id="optionsRadios" onClick={() => setMinper(false)} checked={ minpurchaseamount == 0 && minper == false ? "checked":"" } />
                      None
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input min_purchase" name="min_purchase_amount" onClick={() => setMinper(true)}   checked={ minpurchaseamount != 0 && minper? "checked" :"" } />
                      Minimum Purchase Amount
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  {minper?<input type="number" className="form-control min_purchase_amt" value={minpurchaseamount}
                    onChange={(e) => setMinpurchaseamount(e.target.value)} name="min_purchase_amount" placeholder="$ 0.00" min={0} />:""

                  }
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Customer eligibility</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="everyone" name="eligible" onClick={() => setCust(false)} checked={ customerId == "" ? "checked":"" } />
                      Everyone
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>


                  <div className="form-check" >
                    <label className="form-check-label">
                      <input type="radio" className="form-check-input none eligible" id="single" name="eligible" onClick={() => setCust(true)} checked={ customerId != "" ? "checked":"" }/>
                      Specific Customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                    {cust ?
                      <div id="customer_div" style={{}} data-select2-id="customer_div">


                        {/* <select class="form-control" onChange={(e) => setCustomerId(e.target.value)} multiple>
                          {option.selectOptions.map((options, ind) => (
                            <option key={ind} value={options.value} >{options.label}</option>
                          ))}
                        </select> */}
                              {
                              data.map((element) => {
                              if(element.first_name != null  ){
                                useroptions.push( {value: element.user_id ,label : element.first_name } );
                              }
                              })   
                              }



                              <Select isMulti options={useroptions} onChange={handleChange}/>
                        {/* <Select options={option.selectOptions}    onChange={()=>handleChange.bind(this)} /> */}
                      </div> : ""
                    }
                  </div>

                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Usage Limits</label>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input per_customer" value={1}
                        onChange={(e) => setLimitonepercustomer(e.target.value)} name="limit_one_per_customer" id="optionsRadios" />
                      Limit to one use per customer
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                  <div className="form-check">
                    <label className="form-check-label">
                      <input type="checkbox" className="form-check-input number_of_times_coupon" value={2}
                        onChange={(e) => setUsagelimits(e.target.value)} name="usage_limits" />
                      Limit number of times this discount can be used in total
                      <i className="input-frame" /><i className="input-frame" /></label>
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label>&nbsp;</label>
                  <input type="number" className="form-control number_of_times" name="usage_limits" placeholder={1} min={0} style={{ display: 'none' }} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">Start Date</label>
                  <div className="input-group " id>
                    <input required type="date" id="start_date" value={startdatetime}
                      onChange={(e) => setStartdatetime(e.target.value)} className="form-control" name="start_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
                <div className="form-group col-md-6">
                  <label htmlFor="exampleInputUsername1">End Date</label>
                  <div className="input-group ">
                    <input required type="date" id="end_date" className="form-control" value={enddatetime}
                      onChange={(e) => setEnddatetime(e.target.value)} name="end_datetime" autoComplete="off" />
                    <small style={{ color: 'red' }} />
                  </div>
                </div>
              </div>


              <div className="form-row">
                <div className="col-md-12 form-group text-center">
                  <Button className="btn btn-primary" onClick={updatecoupon}>
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    </div>
    </div>
    </>
  )
}

export {Addcoupon,Editcoupon} 