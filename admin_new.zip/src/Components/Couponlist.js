import { React, useEffect, useState } from 'react';
import { Button, Modal } from "react-bootstrap";
import { API_URL } from "../Helper";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import $ from 'jquery';
import {Addcoupon,Editcoupon} from './Addcoupon';
import Sidebar from './Sidebar';

function Couponlist() {

  const [data, setData] = useState([])
  // modal show open
  const [show, setShow] = useState(false);
  const handleClose = () =>{setUpdatecoup(false); setShow(false);}
  const handleShow = () =>{setUpdatecoup(false); setShow(true);} 

  const [updatecoup, setUpdatecoup] = useState(false);
  const [modalData, setModalData] = useState("");

  // modal show End
  let navigate = useNavigate()

  async function getcoupon(id, status) {
    let url = `${API_URL}admin/Coupon_list`;
    axios.get(url).then((res) => {
      const parsedata = res.data;
      setData(parsedata.data)
    });
  }


  async function update_status(id, status) {
    let item = { status: status, id: id };
    axios.post(`${API_URL}admin/status_coupon`, item).then((res) => {
      var parsedata = res.data;
      console.log(parsedata.status);
      if (parsedata.status === 1) {
        getcoupon()
        navigate("/coupon");
      }

    });

  }



  useEffect(() => {
    getcoupon()

    $(document).ready(function () {
      setTimeout(function () {
        $('#coupon').DataTable();
      }, 1000);
    });

  }, [])

  // console.log(modalData)
  return (

    <>
      <Sidebar />
      <div className='container my-5'>
        <div className=" text-center my-5">
          <h3>Couponlist</h3>
        </div>
        <div className="text-center my-5">
          <Button variant="primary" className='text-center' onClick={handleShow}>
            Add Coupon
          </Button>
        </div>

        <Modal show={show} onHide={handleClose} size="lg">
          <Modal.Header closeButton>
            <Modal.Title>{updatecoup? "Edit Coupon":"Add Coupon"}</Modal.Title>
          </Modal.Header>
          <Modal.Body>{updatecoup?<Editcoupon data={JSON.stringify(modalData)}/>:<Addcoupon />}</Modal.Body>
        </Modal>


        <div className="container my-5">
          <table id="coupon" className="table table-hover table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Coupone Code</th>
                <th>Dicount</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {data && data.map((result, index) => {


                var btn = <></>;


                return (
                  <tr key={result.id}>
                    <td>{index + 1}</td>
                    <td>{result.coupon_code}</td>
                    <td>{result.discount_value}</td>
                    <td>{result.start_datetime}</td>
                    <td>{result.end_datetime}</td>
                    <td>{result.status}</td>
                    <td>{result.status == 1 ? <><Button className='btn-danger mx-2' onClick={() => update_status(result.id, 0)} > Deactivate </Button><Button className='btn-success mx-2' onClick={() =>{ setModalData(result); setUpdatecoup(true);setShow(true);}} > Edit </Button></> : <><Button className='btn-success mx-2' onClick={() => update_status(result.id, 1)} > Activate </Button><><Button className='btn-success mx-2' onClick={() =>{ setModalData(result); setUpdatecoup(true); setShow(true);}} > Edit </Button></></> 
                    }</td>
                  </tr>
                )
              })}


            </tbody>
          </table>

        </div>
      </div>
    </>

  )
}

export default Couponlist