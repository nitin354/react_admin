
import Swal from "sweetalert2";



 export const API_URL = "https://showcase.belgiumwebnet.com/webapi/api/";
 export const BANNER_URL = "https://showcase.belgiumwebnet.com/webapi/assets/images/home/frontslider/";
 export function swalalert(type, Message) {
    Swal.fire({
      type: type,
      text: Message,
    });
  }



